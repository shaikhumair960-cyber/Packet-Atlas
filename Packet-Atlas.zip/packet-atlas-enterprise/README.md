# Packet Atlas Enterprise

Packet Atlas Enterprise is a full-stack PCAP security assessment application. It begins with an empty workspace: results are created only from PCAP/PCAPNG files uploaded into the local workspace.

## What it does

- FastAPI backend with direct local-workspace access, structured error responses, security headers, job logging, SQLite persistence, and ownership checks on every analysis.
- Restart-safe SQLite job recovery, bounded worker concurrency, tenant-scoped account/job queries, schema migrations, and an administrator audit trail.
- Scapy `PcapReader` processes captures one packet at a time from disk. Uploads are written in 1 MiB chunks, hashed while they are stored, and background parsing writes packet metadata to SQLite in 2,000-row batches.
- Captures packet count, timestamps, endpoints, ports, protocol distribution, traffic-by-minute, top IPs/ports, searchable packet rows, streams, and evidence-based asset fingerprints. The inventory records asset type and only passively disclosed OS/runtime details; it does not guess an OS from an address or port.
- Every observed IPv4, IPv6, or ARP endpoint becomes an inventory record, including observed services/ports, packet volume, MAC evidence when available, and passive IP stack profiles. Endpoints without sufficient protocol evidence are clearly marked `Network endpoint` and `Unclassified` instead of being omitted.
- Decodes Modbus function codes, DNP3, IEC 60870-5-104, OPC UA, and Profinet indicators where their transport or frame signatures are present. It flags broad port probing, Telnet, HTTP, HTTP Basic markers, Modbus writes, TCP NULL/XMAS patterns, malformed frames, and direct Purdue L3-to-L1 traffic.
- Maps implemented traffic indicators to MITRE ATT&CK for ICS and produces IEC 62443 / NIST SP 800-82 review evidence, Purdue zones and conduits, OT stream risk scores, asset inventory, and ICS function-code charts. Each detailed vulnerability includes risk, operational impact, affected-device evidence, remediation, and supporting observations.
- React dashboard with upload progress, responsive charts, sortable/filterable packet tables, a Compliance view, blue-and-white enterprise UI, dark-mode preference, reports, and no hardcoded PCAP data.
- CSV, JSON, and PDF report endpoints use the selected analysis only.
- Evidence recovery runs as a background job against the original PCAP. It reconstructs complete, unencrypted HTTP response bodies and TFTP transfers, records endpoints, MIME type, reassembly notes, and SHA-256, and serves each artefact through an ownership-checked download route when API authentication is enabled.
- The Investigation Lab correlates indexed sessions, safe HTTP/FTP/SMTP/POP3 command metadata, SMB session evidence, recovered artefacts, and persistent analyst case notes. The Visual Intelligence view renders an interactive evidence-backed topology, Purdue zone counts, conduit flows, and a capture-quality score based on short frames, retransmission indicators, timing gaps, and encryption coverage.
- DNS intelligence indexes up to 500 unique query records per capture with requester, resolver, query type, timing, repeat count, and query names. It flags sensitive-looking labels plus long encoded-looking labels as evidence for review, without treating a heuristic match as proof of exfiltration.
- FTP analysis correlates observed `USER` and `PASS` commands into session evidence and raises a critical remediation record. RDP negotiation responses are classified as TLS, CredSSP/Hybrid, Hybrid EX, or legacy standard RDP security; only an observed negotiation response is classified. Directly disclosed FTP, SSH, SMTP, and HTTP product strings augment passive asset fingerprint evidence.
- The Packet Explorer provides packet-level, byte-derived ICS explanations for Modbus TCP, DNP3, IEC 60870-5-104, OPC UA, and PROFINET. Modbus includes transaction, unit, and function; DNP3 includes link addresses and command type; IEC 104 includes APDU/ASDU detail; OPC UA includes transport message framing. S7comm, EtherNet/IP, and BACnet port observations are clearly marked as transport identification when a deeper command decoder is unavailable.
- Analyst workflow additions correlate ICS exchanges into client/server transactions with request and response counts, operation history, frame references, write/control counts, and bounded TCP sequence-gap evidence. S7comm, EtherNet/IP CIP encapsulation, BACnet BVLC, and PROFINET DCP framing now receive byte-derived packet narratives when their framing is present.

## Run with Docker

1. Copy `.env.example` to `.env`.
2. The supplied `.env.example` opens the workspace directly with `AUTH_REQUIRED=false`.
3. From this `enterprise` directory, run:

   ```bash
   docker compose up --build
   ```

4. Open `http://localhost:8000` and upload a PCAP.

The local workspace runs as the configured local administrator and does not show a sign-in screen. Legacy account administration remains available in Settings for deployments that use the optional API authentication endpoints.

Set a unique `TENANT_ID` for each isolated deployment. Every account, upload, analysis, report, and audit event is scoped to that tenant. The admin Settings view includes the tenant's audit trail and can request an NVD cache refresh.

## Confirmed asset enrichment

In **Settings → Confirmed asset enrichment**, an administrator can download the CSV template and import a tenant-specific CMDB or asset register. The importer accepts these columns:

```text
ip,asset_name,asset_type,vendor,model,firmware,operating_system,zone,criticality
```

The import replaces the tenant's prior confirmed asset set. Re-analyze a PCAP after importing: Packet Atlas merges records only when the corresponding IP is observed in that capture. Confirmed vendor, model, firmware, and OS enrich exports and provide stronger CPE evidence for local NVD CVE matching.

## Analyst workflow and baselines

After a capture completes, open **Reports** and use **Mark as baseline** to retain its observed asset, service, stream, control-transaction, zone, fingerprint, and DNS evidence as a known-good reference. Select that baseline while reviewing another completed capture to surface new assets, ports, passive fingerprint changes, control/write sequences, remote-access paths, Purdue conduits, and DNS indicators. Each comparison result links to the observed evidence and prioritizes production-impacting changes.

The investigation and packet explorer views preserve packet number, timestamp, endpoints, decoded operation, stream context, and analyst notes. Findings expose their original evidence items through the API for packet-level review.

The named Docker volume `packet-atlas-data` keeps uploads and results. Remove the stack and volume only when you intend to delete captured data:

```bash
docker compose down
```

## Local development

Backend:

```bash
python -m venv .venv
. .venv/bin/activate  # Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r backend/requirements.txt
uvicorn app.main:app --app-dir backend --reload
```

Frontend, in a second terminal:

```bash
cd frontend
npm install
npm run dev
```

The development server proxies `/api` to FastAPI. For production, Docker builds the React application and FastAPI serves it under the same origin.

The root URL returns the React dashboard. If `/` returns JSON `{"detail":"Not Found"}`, update to the current package: the application could not locate the static frontend in an earlier archive.

For a simple local test after building the frontend, run this from the `enterprise` directory:

```bash
python server.py
```

It binds only to `127.0.0.1:8000` by default and fails with an actionable message if Python dependencies or the built frontend are missing.

## Evidence recovery

Open **Evidence recovery** after the selected analysis is complete and choose **Start recovery**. The job reads the already-uploaded PCAP from disk, so it does not upload or duplicate the capture. It performs best-effort TCP stream assembly for unencrypted HTTP responses and reconstructs complete TFTP data-block transfers. Recovered files are listed with source/destination, MIME type, SHA-256, and a protected download button.

TLS/HTTPS, SSH, encrypted SMB, and any protocol payload encrypted in the capture cannot be reconstructed without the relevant session keys; Packet Atlas does not attempt to bypass encryption. Missing or incomplete TCP segments are also withheld rather than producing a misleading file. Recovered artefacts can be sensitive and are retained beneath `data/recovered` with the upload data; apply the same encryption, access-control, backup, and retention controls.

The defaults cap an individual recovered artefact at 100 MiB, a reassembled stream at 256 MiB, and a job at 1,000 files. Set `MAX_RECOVERED_FILE_BYTES`, `MAX_RECOVERY_STREAM_BYTES`, and `MAX_RECOVERED_FILES` in `.env` to suit the deployment capacity.

## Explainable evidence and operations

Use **Evidence inspector** after an analysis completes to select a traffic finding and review the exact indexed packets that caused it. The screen preserves the finding's rule evidence alongside frame numbers, capture timestamps, endpoints, and the decoder's communication explanation. It makes an observed conclusion reviewable without turning an inference into a claim of compromise.

Use **Operations** to see tenant-scoped completed, queued, and running captures; recovery work; active worker capacity; evidence-storage use; the per-upload limit; and the most recent capture error. This is intended for diagnosing an unsupported capture or planning large PCAP ingestion. It never exposes another tenant's jobs or storage figures.

## OT transaction analysis

Open **Transactions** to work from controller conversations rather than packet counts. Packet Atlas pairs visible request and response frames using Modbus transaction/unit/function fields, S7 PDU references, and EtherNet/IP sender contexts where those fields are present. The view records request and response frame numbers, timestamps, decoded operations, round-trip time, control-write status, rejected Modbus/EtherNet-IP replies, and requests for which no response was observed.

Protocols without a safe transaction identifier use FIFO pairing within the observed client/server flow and are labelled as such. A missing response can result from packet loss, asymmetric capture, encryption, or a device issue; it is presented as an observation for analyst review rather than an availability conclusion.

## API

The bundled local configuration exposes PCAP and reporting routes directly. API clients may still use the optional JWT endpoint when `AUTH_REQUIRED=true` is configured.

| Method | Endpoint | Purpose |
| --- | --- | --- |
| POST | `/api/auth/login` | Optional: issue a short-lived JWT for API deployments with authentication enabled. |
| GET / POST | `/api/admin/users` | Administrator-only account listing and creation. |
| PATCH | `/api/admin/users/{username}` | Administrator-only password, role, and enable/disable controls. |
| GET | `/api/cves/status` | Reports whether the configured local NVD JSON feed is available. |
| GET | `/api/operations/status` | Tenant-scoped worker, queue, storage, and recent-failure telemetry. |
| POST | `/api/admin/cves/refresh` | Administrator-only background refresh of the NVD delta cache. |
| GET | `/api/admin/audit` | Administrator-only tenant audit trail. |
| GET | `/api/admin/assets/template` | Administrator-only confirmed-asset CSV template. |
| POST | `/api/admin/assets/import` | Replace the tenant's confirmed asset enrichment from a UTF-8 CSV. |
| POST | `/api/pcaps` | Stream an uploaded `.pcap`, `.pcapng`, or `.cap` into an async analysis job. |
| GET | `/api/pcaps` | List the signed-in user's jobs. |
| GET | `/api/pcaps/{id}` | Get job status, computed summary, and findings. |
| GET | `/api/pcaps/{id}/packets` | Search and paginate parsed packets. |
| GET | `/api/pcaps/{id}/findings/{finding_id}/evidence` | Return a finding and the indexed packets referenced by its evidence. |
| GET | `/api/baselines` | List saved workspace baselines. |
| POST | `/api/pcaps/{id}/baseline` | Save a completed capture as a baseline snapshot. |
| GET | `/api/pcaps/{id}/compare/{baseline_id}` | Compare the current capture against a saved baseline. |
| GET / POST | `/api/pcaps/{id}/case-notes` | Read or save analyst case notes for one capture. |
| POST | `/api/pcaps/{id}/recoveries` | Queue a supported file-recovery job after analysis completes. |
| GET | `/api/pcaps/{id}/recoveries` | List recovery jobs for the selected capture. |
| GET | `/api/recoveries/{id}` | Get recovery progress and recovered-file metadata. |
| GET | `/api/recoveries/{id}/files/{file_id}` | Download one authenticated recovered artefact. |
| GET | `/api/pcaps/{id}/reports/{csv,json,pdf}` | Download a report. |
| GET | `/api/pcaps/{id}/assets/reports/{csv,json,pdf}` | Export the selected capture's asset inventory. |
| GET | `/api/pcaps/{id}/vulnerabilities/reports/{csv,json,pdf}` | Export its traffic findings and CVE candidates. |

Interactive OpenAPI documentation is available at `/api/docs`.

## Production notes

- Place the container behind a TLS reverse proxy and set `ALLOWED_HOSTS` to the real hostnames.
- This build has no sign-in page and defaults to direct local access. Keep it on a trusted local network. If you enable `AUTH_REQUIRED=true`, protect it behind your own gateway or supply JWTs to the API; the bundled user interface intentionally remains sign-in-free.
- Uploads may contain sensitive network data. The app persists them under `/data/uploads`; use encrypted persistent storage, restrictive backups, retention policies, and access controls appropriate to your environment.
- The `MAX_UPLOAD_BYTES` default is 2 GiB. `MAX_INDEXED_PACKETS` limits storage growth; make this capacity decision deliberately. Scapy parsing remains streaming, but the SQLite packet index and reports necessarily consume disk.
- `PACKET_DB_BATCH_SIZE` defaults to 5,000 rows to reduce SQLite commit overhead, and `MAX_PAYLOAD_INSPECTION_BYTES` defaults to 4 KiB to bound deep-inspection work. Increase these only after measuring memory, disk, and parser throughput on representative captures.
- File reconstruction is intentionally limited to unencrypted HTTP and TFTP in this release. It is best-effort forensic recovery, not a decryption service; preserve captures and validate recovered content with its reported SHA-256 before operational use.
- For offline CVE mapping, download an official NVD JSON 2.0 feed and mount or copy it to `data/nvd-cves.json`, or set `CVE_FEED_PATH` to its location. The matcher needs an observed service/product banner plus matching CPE vendor/product tokens; it does not infer a CVE from a port alone.
- The NVD refresh worker checks the local cache every `NVD_REFRESH_HOURS` (24 by default) and requests incremental changes from the NVD API. Seed a full official feed when historical CVE matching is needed; optionally set `NVD_API_KEY` for higher API throughput.
- Scapy does not decrypt TLS or validate device firmware. A candidate traffic indicator, asset role, CVE match, ATT&CK technique, or compliance control is evidence for review, not proof of exploitability or compliance determination.
- A PCAP with encrypted traffic, no application payload, or no industrial protocol traffic cannot reliably reveal a product version, OS, or CVE. Packet Atlas exposes the available endpoint and flow evidence in those cases rather than inventing a fingerprint.
