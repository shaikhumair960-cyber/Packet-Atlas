#!/usr/bin/env python3
"""Run Packet Atlas Enterprise locally without Docker.

Usage:
  python server.py
  python server.py --host 127.0.0.1 --port 8000

Install backend requirements first:
  python -m pip install -r backend/requirements.txt
"""
from __future__ import annotations

import argparse
import importlib.util
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BACKEND = ROOT / "backend"
FRONTEND = ROOT / "frontend" / "dist"
REQUIRED = ("fastapi", "uvicorn", "scapy", "multipart", "reportlab")

def load_dotenv() -> None:
    """Read a minimal local .env without adding a runtime dependency."""
    env_file = ROOT / ".env"
    if not env_file.is_file():
        return
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))

def main() -> None:
    parser = argparse.ArgumentParser(description="Run Packet Atlas Enterprise locally.")
    parser.add_argument("--host", default="127.0.0.1", choices=("127.0.0.1", "localhost"), help="Loopback host only.")
    parser.add_argument("--port", default=8000, type=int, help="HTTP port (default: 8000).")
    parser.add_argument("--reload", action="store_true", help="Enable source reload for development.")
    args = parser.parse_args()
    load_dotenv()
    missing = [name for name in REQUIRED if importlib.util.find_spec(name) is None]
    if missing:
        parser.exit(1, "Missing Python dependencies: " + ", ".join(missing) + "\nRun: python -m pip install -r backend/requirements.txt\n")
    if not FRONTEND.is_dir():
        parser.exit(1, "Missing frontend/dist. Build it once with: cd frontend && npm install && npm run build\n")
    if not 1 <= args.port <= 65535:
        parser.error("Port must be between 1 and 65535.")
    sys.path.insert(0, str(BACKEND))
    import uvicorn
    print(f"Packet Atlas Enterprise is running at http://{args.host}:{args.port}", flush=True)
    uvicorn.run("app.main:app", host=args.host, port=args.port, reload=args.reload, log_level="info")

if __name__ == "__main__":
    main()
