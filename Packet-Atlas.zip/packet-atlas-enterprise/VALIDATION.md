# Validation record

- Python source compilation: passed for `backend/app`, including the restart-safe worker, migration layer, tenant scoping, audit log, OT analyzer, NVD matcher/refresh scheduler, and file-recovery worker.
- Backend tests: passed. They validate tenant boundaries and audit events, case-note ownership, CMDB CSV validation and tenant scoping, owned packet pagination, account creation and updates, local NVD banner/CPE matching, recovery-job persistence, and full plus focused asset/vulnerability CSV, JSON, and PDF exports. Synthetic Scapy regression captures cover OT control, IT exposure, encrypted traffic, endpoint discovery, malformed frames, port scanning, and an HTTP file-recovery response; those runtime tests are skipped locally because Scapy and FastAPI are installed by the Docker image rather than this workstation runtime.
- Frontend production build: passed with Vite. The only output is Vite's advisory that the application JavaScript bundle exceeds 500 kB after minification.
- Demo-data source scan: passed. There are no manufacturing-demo, synthetic-demo, or `demoCapture` references in the deployable enterprise source.
- Docker Compose build: not run because Docker is not installed on this workstation.
- Full Scapy/FastAPI runtime test: not run locally because those dependencies are installed by the Docker image and are not preinstalled in this workspace.
- Static mount path: checked for both the source checkout and Docker's `/app/frontend/dist` location.

The Docker build installs the pinned backend requirements and builds the React frontend before starting FastAPI.
