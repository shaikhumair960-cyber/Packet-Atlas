export default {content:['./index.html','./src/**/*.{js,jsx}'],theme:{extend:{colors:{navy:'#102a43',blue:'#1f63b8'} }},plugins:[]};
