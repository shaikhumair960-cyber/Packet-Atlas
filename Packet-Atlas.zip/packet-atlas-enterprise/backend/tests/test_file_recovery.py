import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
try:
    from app import db, recovery
    from scapy.all import Ether, IP, Raw, TCP, PcapWriter
    AVAILABLE = True
except ImportError:
    AVAILABLE = False


@unittest.skipUnless(AVAILABLE, "Scapy is installed by the application runtime or Docker image")
class FileRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.previous_db, self.previous_recovery_dir = db.DB_PATH, recovery.RECOVERY_DIR
        db.DB_PATH = Path(self.temp.name) / "recovery.sqlite3"
        recovery.RECOVERY_DIR = Path(self.temp.name) / "recovered"
        db.initialize()

    def tearDown(self):
        db.DB_PATH, recovery.RECOVERY_DIR = self.previous_db, self.previous_recovery_dir
        self.temp.cleanup()

    def test_recovers_an_unencrypted_http_response(self):
        body = b"asset,value\nplc-1,green\n"
        capture = Path(self.temp.name) / "transfer.pcap"
        request = b"GET /exports/inventory.csv HTTP/1.1\r\nHost: historian\r\n\r\n"
        response = b"HTTP/1.1 200 OK\r\nContent-Type: text/csv\r\nContent-Disposition: attachment; filename=inventory.csv\r\nContent-Length: " + str(len(body)).encode() + b"\r\n\r\n" + body
        writer = PcapWriter(str(capture), sync=True)
        try:
            writer.write(Ether()/IP(src="10.0.0.10", dst="10.0.0.20")/TCP(sport=51422, dport=80, seq=1, flags="PA")/Raw(request))
            writer.write(Ether()/IP(src="10.0.0.20", dst="10.0.0.10")/TCP(sport=80, dport=51422, seq=1, flags="PA")/Raw(response))
            writer.write(Ether()/IP(src="10.0.0.10", dst="10.0.0.30")/TCP(sport=51423, dport=443, seq=1, flags="PA")/Raw(b"\x16\x03\x03\x00\x10"))
        finally:
            writer.close()
        db.create_job({"id":"analysis-1","owner":"analyst","tenant":"test","filename":"transfer.pcap","path":str(capture),"sha256":"0" * 64,"size":capture.stat().st_size,"created":1.0})
        db.create_recovery_job({"id":"recovery-1","analysis_id":"analysis-1","owner":"analyst","tenant":"test","path":str(capture),"created":1.0})
        recovery.recover_job("recovery-1", str(capture))
        job = db.recovery_for_owner("recovery-1", "analyst", "test")
        files = db.recovered_files("recovery-1", "analyst", "test")
        self.assertEqual(job["status"], "complete")
        self.assertEqual(len(files), 1)
        self.assertEqual(files[0]["name"], "inventory.csv")
        self.assertEqual(files[0]["protocol"], "HTTP")
        self.assertEqual((recovery.RECOVERY_DIR / "recovery-1" / "files" / f"{files[0]['id']:05d}-inventory.csv").read_bytes(), body)


if __name__ == "__main__":
    unittest.main()
