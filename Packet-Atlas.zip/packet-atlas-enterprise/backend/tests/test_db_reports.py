import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import baseline, cve, db, enrichment, reports

class DatabaseAndReportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.previous = db.DB_PATH
        db.DB_PATH = Path(self.temp.name) / "test.sqlite3"
        db.initialize()
        db.create_job({"id":"job","owner":"analyst","tenant":"tenant-a","filename":"capture.pcap","path":"/tmp/capture.pcap","sha256":"a"*64,"size":42,"created":1.0})

    def tearDown(self):
        db.DB_PATH = self.previous
        self.temp.cleanup()

    def test_packet_pagination_is_owned_and_searchable(self):
        with db.connection() as conn:
            conn.execute("INSERT INTO packets VALUES(?,?,?,?,?,?,?,?,?,?,?)", ("job",1,10.0,"10.0.0.1","10.0.0.2",50000,502,"Modbus TCP",60,"Read holding registers","PA"))
        page = db.packet_page("job","analyst","tenant-a","Modbus",0,100)
        self.assertEqual(page["total"],1)
        with self.assertRaises(KeyError): db.packet_page("job","other","tenant-a","",0,100)

    def test_pdf_json_and_csv_exports(self):
        db.complete_analysis("job", [{"id":"http","severity":"Medium","title":"HTTP","description":"Observed","recommendation":"Use TLS","count":1,"evidence":[]}], {"packet_count":1,"protocols":[{"name":"HTTP","count":1}]})
        analysis = db.analysis("job","analyst","tenant-a")
        for fmt, signature in (("json",b"{"),("csv",b"Packet Atlas"),("pdf",b"%PDF")):
            data, _, extension = reports.build(analysis,fmt)
            self.assertTrue(data.lstrip(b"\xef\xbb\xbf").startswith(signature))
            self.assertEqual(extension,fmt)

    def test_focused_asset_and_vulnerability_exports(self):
        db.complete_analysis("job", [{"id":"modbus-write","severity":"High","title":"Modbus write","description":"Observed","recommendation":"Validate","count":1,"evidence":[]}], {"packet_count":1,"assets":[{"ip":"10.0.0.5","types":["PLC"],"services":["Modbus TCP"],"zones":["Purdue L1"],"confidence":70,"banners":[]}],"cves":[{"asset":"10.0.0.5","id":"CVE-2099-0001","cvss":8.1,"description":"Example","remediation":"Patch"}]})
        analysis = db.analysis("job", "analyst", "tenant-a")
        data, _, extension = reports.build_section(analysis, "assets", "csv")
        self.assertIn(b"10.0.0.5", data)
        self.assertEqual(extension, "csv")
        data, _, extension = reports.build_section(analysis, "vulnerabilities", "json")
        self.assertIn(b"CVE-2099-0001", data)
        self.assertEqual(extension, "json")

    def test_user_accounts_can_be_created_and_updated(self):
        db.create_user("admin", "hash-one", "admin", "tenant-a")
        account = db.user("admin", "tenant-a")
        self.assertEqual(account["role"], "admin")
        self.assertEqual(account["enabled"], 1)
        self.assertTrue(db.update_user("admin", "tenant-a", password_hash="hash-two", role="auditor", enabled=False))
        updated = db.user("admin", "tenant-a")
        self.assertEqual(updated["password_hash"], "hash-two")
        self.assertEqual(updated["role"], "auditor")
        self.assertEqual(updated["enabled"], 0)
        self.assertEqual(db.users("tenant-a")[0]["username"], "admin")

    def test_tenant_boundaries_and_audit_events(self):
        with self.assertRaises(KeyError):
            db.analysis("job", "analyst", "tenant-b")
        db.audit("tenant-a", "analyst", "capture.upload", {"job_id": "job"})
        self.assertEqual(db.audit_events("tenant-a")[0]["action"], "capture.upload")
        self.assertEqual(db.audit_events("tenant-b"), [])

    def test_operations_status_is_tenant_scoped(self):
        db.update_job("job", status="failed", error="Unsupported capture")
        status = db.operations_status("analyst", "tenant-a")
        self.assertEqual(status["jobs"]["failed"], 1)
        self.assertEqual(status["upload_bytes"], 42)
        self.assertEqual(status["recent_failures"][0]["filename"], "capture.pcap")
        self.assertEqual(db.operations_status("analyst", "tenant-b")["upload_bytes"], 0)

    def test_case_notes_are_owned_by_the_selected_analysis(self):
        note_id=db.add_case_note("job", "analyst", "tenant-a", "Analyst note", "Controller review", "Validate the observed write against the maintenance record.")
        notes=db.case_notes("job", "analyst", "tenant-a")
        self.assertEqual(notes[0]["id"], note_id)
        self.assertEqual(notes[0]["label"], "Controller review")
        with self.assertRaises(KeyError): db.case_notes("job", "other", "tenant-a")

    def test_baseline_comparison_finds_new_ot_evidence(self):
        snapshot={"assets":[{"ip":"10.0.0.5","asset_type":"PLC","zones":["Purdue L1"],"banners":[]}],"top_ports":[{"port":502}],"transactions":[],"streams":[],"zone_streams":[],"dns_stats":{"sensitive_indicators":0}}
        db.create_baseline({"id":"baseline","analysis_id":"job","owner":"analyst","tenant":"tenant-a","name":"Known good","snapshot":json.dumps(snapshot),"created":1.0})
        result=baseline.compare(db.baseline_for_owner("baseline","analyst","tenant-a"),{"assets":[*snapshot["assets"],{"ip":"10.0.0.9","asset_type":"PLC","zones":["Purdue L1"],"banners":[]}],"top_ports":[{"port":502},{"port":44818}],"transactions":[],"streams":[],"zone_streams":[],"dns_stats":{"sensitive_indicators":1}})
        self.assertGreaterEqual(result["summary"]["total"],3)
        self.assertTrue(any(item["type"]=="New asset" for item in result["deviations"]))

    def test_cmdb_csv_enrichment_is_validated_and_tenant_scoped(self):
        records = enrichment.parse_csv(b"IP Address,Name,Asset Type,Vendor,Model,OS,Zone,Criticality\n10.0.0.8,PLC-01,PLC,Siemens,S7-1500,VxWorks,Purdue L1,High\n")
        self.assertEqual(records[0]["ip"], "10.0.0.8")
        self.assertEqual(records[0]["operating_system"], "VxWorks")
        db.replace_asset_enrichment("tenant-a", records)
        self.assertEqual(db.asset_enrichment("tenant-a")["10.0.0.8"]["asset_name"], "PLC-01")
        self.assertEqual(db.asset_enrichment("tenant-b"), {})
        with self.assertRaises(ValueError): enrichment.parse_csv(b"name\nasset\n")

    def test_local_nvd_feed_maps_only_banner_backed_assets(self):
        feed = Path(self.temp.name) / "nvd.json"
        feed.write_text(json.dumps({
            "vulnerabilities": [{"cve": {
                "id": "CVE-2099-0001",
                "descriptions": [{"lang": "en", "value": "Example finding"}],
                "metrics": {"cvssMetricV31": [{"cvssData": {"baseScore": 8.1}}]},
                "configurations": [{"nodes": [{"cpeMatch": [{"criteria": "cpe:2.3:a:siemens:simatic:1.0:*:*:*:*:*:*:*"}]}]}],
            }}],
        }), encoding="utf-8")
        previous = cve.CVE_FEED_PATH
        cve.CVE_FEED_PATH = str(feed)
        try:
            matches = cve.match_assets([{"ip": "10.0.0.5", "types": ["PLC / Modbus server"], "services": ["Modbus TCP"], "banners": ["Siemens SIMATIC 1.0"]}])
        finally:
            cve.CVE_FEED_PATH = previous
        self.assertEqual(matches[0]["id"], "CVE-2099-0001")
        self.assertEqual(matches[0]["cvss"], 8.1)

if __name__ == "__main__": unittest.main()
