# PCAP regression corpus

`pcap_corpus.py` generates deterministic PCAPs at test time so the repository does
not contain third-party, sensitive, or captured production traffic.

| Case | Coverage |
| --- | --- |
| `ot_control` | Modbus write, DNP3 operate, IEC 104 command, and OPC UA handshake evidence. |
| `transaction_pairs` | Matched Modbus write and read transactions, response timing, and a decoded exception response. |
| `it_services` | SMB, RDP, SSH, HTTP, banner, and remote-access findings. |
| `encrypted` | TLS flows and generic endpoint inventory with no invented OS/CVE. |
| `noisy_discovery` | ARP, DNS, ICMP, endpoint inventory, MACs, and stack profiles. |
| `malformed_and_scan` | Short frame and destination-port probing indicators. |

Run all regression tests in a dependency-complete environment:

```bash
python -m unittest discover -s backend/tests -v
```
