"""Deterministic PCAP corpus for Packet Atlas end-to-end regression tests.

These are synthetic, minimally scoped packets. They do not represent real production
captures or exploit traffic; their role is to lock in parser behavior as decoders grow.
"""
from pathlib import Path

from scapy.all import ARP, DNS, DNSQR, Ether, ICMP, IP, Raw, TCP, UDP, PcapWriter


def _packet(src, dst, sport, dport, payload=b""):
    return Ether(src="02:00:00:00:00:01", dst="02:00:00:00:00:02") / IP(src=src, dst=dst, ttl=64) / TCP(sport=sport, dport=dport, flags="PA") / Raw(payload)


def _ot_control():
    return [
        _packet("10.10.1.10", "10.10.1.20", 51000, 502, b"\x00\x01\x00\x00\x00\x06\x01\x10\x00\x00"),
        _packet("10.10.1.10", "10.10.1.21", 51001, 20000, b"\x05\x64" + b"\x00" * 10 + b"\x04"),
        _packet("10.10.1.10", "10.10.1.22", 51002, 2404, b"\x68\x04\x00\x00\x00\x00\x2d"),
        _packet("10.10.1.10", "10.10.1.23", 51003, 4840, b"HEL\x46\x00\x00\x00"),
    ]


def _transaction_pairs():
    """Modbus request/response examples, including a visible exception reply."""
    return [
        _packet("10.11.1.10", "10.11.1.20", 52000, 502, b"\x00\x01\x00\x00\x00\x06\x01\x10\x00\x00"),
        _packet("10.11.1.20", "10.11.1.10", 502, 52000, b"\x00\x01\x00\x00\x00\x06\x01\x10\x00\x00"),
        _packet("10.11.1.10", "10.11.1.20", 52000, 502, b"\x00\x02\x00\x00\x00\x06\x01\x03\x00\x00"),
        _packet("10.11.1.20", "10.11.1.10", 502, 52000, b"\x00\x02\x00\x00\x00\x03\x01\x83\x02"),
    ]


def _it_services():
    return [
        _packet("192.168.1.10", "192.168.1.20", 51000, 445, b"SMB"),
        _packet("192.168.1.10", "192.168.1.21", 51001, 3389, b"RDP"),
        _packet("192.168.1.10", "192.168.1.22", 51002, 22, b"SSH-2.0-test"),
        _packet("192.168.1.30", "192.168.1.10", 80, 51003, b"HTTP/1.1 200 OK\r\nServer: Example Linux\r\n\r\n"),
    ]


def _encrypted():
    return [
        _packet("172.16.1.10", "172.16.1.20", 52000, 443, b"\x16\x03\x01\x00\x20"),
        _packet("172.16.1.20", "172.16.1.10", 443, 52000, b"\x16\x03\x03\x00\x20"),
    ]


def _noisy_discovery():
    return [
        Ether(src="02:00:00:00:00:03", dst="ff:ff:ff:ff:ff:ff") / ARP(psrc="10.2.0.1", pdst="10.2.0.2"),
        Ether(src="02:00:00:00:00:04", dst="02:00:00:00:00:05") / IP(src="10.2.0.2", dst="10.2.0.53", ttl=128) / UDP(sport=53000, dport=53) / DNS(rd=1, qd=DNSQR(qname="plc.example")),
        Ether(src="02:00:00:00:00:04", dst="02:00:00:00:00:05") / IP(src="10.2.0.2", dst="10.2.0.1", ttl=128) / ICMP(),
    ]


def _malformed_and_scan():
    packets = [Ether(src="02:00:00:00:00:06", dst="02:00:00:00:00:07")]
    packets.extend(_packet("10.3.0.10", "10.3.0.20", 40000 + port, port) for port in range(1000, 1020))
    return packets


CASES = {
    "ot_control": _ot_control,
    "transaction_pairs": _transaction_pairs,
    "it_services": _it_services,
    "encrypted": _encrypted,
    "noisy_discovery": _noisy_discovery,
    "malformed_and_scan": _malformed_and_scan,
}


def write_case(name: str, directory: Path) -> Path:
    if name not in CASES:
        raise KeyError(name)
    path = directory / f"{name}.pcap"
    writer = PcapWriter(str(path), sync=True)
    try:
        for number, packet in enumerate(CASES[name](), start=1):
            packet.time = 1_700_000_000 + number
            writer.write(packet)
    finally:
        writer.close()
    return path
