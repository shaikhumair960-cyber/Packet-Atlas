"""Synthetic packet-capture regression fixtures."""
