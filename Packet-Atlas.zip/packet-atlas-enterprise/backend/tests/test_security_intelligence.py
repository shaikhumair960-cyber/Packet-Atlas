import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
try:
    from app import analyzer, auth, db
    AVAILABLE = True
except ImportError:
    AVAILABLE = False

@unittest.skipUnless(AVAILABLE, "FastAPI and Scapy are installed by the application environment")
class SecurityIntelligenceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.previous = db.DB_PATH
        db.DB_PATH = Path(self.temp.name) / "security.sqlite3"; db.initialize()

    def tearDown(self):
        db.DB_PATH = self.previous; self.temp.cleanup()

    def test_ics_operation_decoders_identify_control_commands(self):
        operation, function, write = analyzer._ics_detail("Modbus TCP", b"\0\0\0\0\0\x02\x01\x10")
        self.assertEqual(function, "16"); self.assertTrue(write); self.assertIn("Write multiple", operation)
        operation, function, write = analyzer._ics_detail("DNP3", b"\x05\x64" + b"\0" * 10 + b"\x04")
        self.assertEqual(function, "4"); self.assertTrue(write); self.assertIn("Operate", operation)
        operation, function, write = analyzer._ics_detail("IEC 60870-5-104", b"\x68\x04\0\0\0\0\x2d")
        self.assertEqual(function, "45"); self.assertTrue(write); self.assertIn("Single command", operation)

    def test_password_hashes_and_tenant_scoped_accounts(self):
        encoded = auth.hash_password("valid-password")
        self.assertTrue(auth.verify_password("valid-password", encoded))
        self.assertFalse(auth.verify_password("incorrect", encoded))
        db.create_user("engineer", encoded, "engineer", "tenant-a")
        self.assertIsNotNone(db.user("engineer", "tenant-a"))
        self.assertIsNone(db.user("engineer", "tenant-b"))

    def test_every_observed_endpoint_receives_a_generic_asset_record(self):
        assets = {}
        asset = analyzer._asset(assets, "10.0.0.10")
        self.assertEqual(asset["types"], {"Network endpoint"})
        self.assertEqual(analyzer._asset_type(asset["types"]), "Network endpoint")
        asset["types"].add("PLC / Modbus server")
        self.assertEqual(analyzer._asset_type(asset["types"]), "PLC / Modbus server")

if __name__ == "__main__": unittest.main()
