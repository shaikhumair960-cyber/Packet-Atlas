import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
try:
    from app import analyzer, db
    from fixtures.pcap_corpus import write_case
    AVAILABLE = True
except ImportError:
    AVAILABLE = False


@unittest.skipUnless(AVAILABLE, "Scapy is installed by the application runtime or Docker image")
class PcapRegressionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.previous = db.DB_PATH
        db.DB_PATH = Path(self.temp.name) / "regression.sqlite3"
        db.initialize()

    def tearDown(self):
        db.DB_PATH = self.previous
        self.temp.cleanup()

    def analyze(self, name):
        capture = write_case(name, Path(self.temp.name))
        job_id = f"case-{name}"
        db.create_job({"id": job_id, "owner": "regression", "tenant": "test", "filename": capture.name, "path": str(capture), "sha256": "0" * 64, "size": capture.stat().st_size, "created": 1.0})
        analyzer.parse_job(job_id, str(capture))
        return db.analysis(job_id, "regression", "test")

    def test_ot_control_protocols_assets_flows_and_findings(self):
        result = self.analyze("ot_control")
        protocols = {item["name"] for item in result["summary"]["protocols"]}
        self.assertTrue({"Modbus TCP", "DNP3", "IEC 60870-5-104", "OPC UA"}.issubset(protocols))
        assets = {item["ip"]: item for item in result["summary"]["assets"]}
        self.assertIn("PLC / Modbus server", assets["10.10.1.20"]["types"])
        self.assertTrue(any(item["protocol"] == "Modbus TCP" for item in result["summary"]["streams"]))
        findings = {item["id"] for item in result["findings"]}
        self.assertIn("modbus-write", findings)
        self.assertIn("ics-control", findings)
        page = db.packet_page("case-ot_control", "regression", "test", "Modbus", 0, 100)
        self.assertIn("unit 1", page["packets"][0]["info"])
        self.assertIn("changes controller state", page["packets"][0]["info"])

    def test_transaction_pairs_preserve_response_time_and_rejections(self):
        result = self.analyze("transaction_pairs")
        transaction = next(item for item in result["summary"]["transactions"] if item["protocol"] == "Modbus TCP")
        self.assertEqual(transaction["matched"], 2)
        self.assertEqual(transaction["rejected"], 1)
        self.assertEqual(transaction["unanswered"], 0)
        self.assertEqual(transaction["response_time_ms_avg"], 1000.0)
        self.assertTrue(any(item["status"].startswith("Rejected") for item in transaction["exchanges"]))
        self.assertEqual(result["summary"]["transaction_stats"]["matched"], 2)

    def test_it_services_create_contextual_exposure_findings(self):
        result = self.analyze("it_services")
        findings = {item["id"] for item in result["findings"]}
        self.assertTrue({"remote-access", "smb-exposure"}.issubset(findings))
        asset = next(item for item in result["summary"]["assets"] if item["ip"] == "192.168.1.30")
        self.assertIn("Linux", asset["os"])

    def test_encrypted_capture_remains_useful_without_fabricated_fingerprint(self):
        result = self.analyze("encrypted")
        protocols = {item["name"] for item in result["summary"]["protocols"]}
        self.assertIn("TLS", protocols)
        assets = result["summary"]["assets"]
        self.assertEqual(len(assets), 2)
        self.assertTrue(any(item["asset_type"] != "" for item in assets))
        self.assertTrue(all(item["os"] == ["Not observed"] for item in assets))

    def test_noisy_capture_keeps_endpoint_and_stack_evidence(self):
        result = self.analyze("noisy_discovery")
        assets = {item["ip"]: item for item in result["summary"]["assets"]}
        self.assertIn("10.2.0.2", assets)
        self.assertTrue(assets["10.2.0.2"]["macs"])
        self.assertTrue(assets["10.2.0.2"]["stack_profiles"])
        self.assertGreaterEqual(result["summary"]["packet_count"], 3)

    def test_dns_queries_are_indexed_as_investigable_evidence(self):
        result = self.analyze("noisy_discovery")
        queries = result["summary"]["dns_queries"]
        self.assertEqual(queries[0]["name"], "plc.example")
        self.assertEqual(queries[0]["qtype"], "A")
        self.assertEqual(result["summary"]["dns_stats"]["unique_queries"], 1)

    def test_malformed_and_scan_indicators_are_regressed(self):
        result = self.analyze("malformed_and_scan")
        findings = {item["id"] for item in result["findings"]}
        self.assertTrue({"malformed-frame", "port-scan"}.issubset(findings))


if __name__ == "__main__": unittest.main()
