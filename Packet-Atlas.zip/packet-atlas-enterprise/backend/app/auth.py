"""Small JWT implementation using only the Python standard library.

HS256 tokens are used so deployment does not depend on an opaque auth SDK.
Passwords are only read from environment variables; production must set them.
"""
import base64
import binascii
import hashlib
import hmac
import json
import time
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from .config import ADMIN_PASSWORD, ADMIN_USERNAME, AUTH_REQUIRED, JWT_SECRET, JWT_TTL_MINUTES, LOCAL_USERNAME, TENANT_ID
from . import db

bearer = HTTPBearer(auto_error=False)

def _encode(value: dict) -> str:
    return base64.urlsafe_b64encode(json.dumps(value, separators=(",", ":")).encode()).rstrip(b"=").decode()

def _decode(value: str) -> dict:
    return json.loads(base64.urlsafe_b64decode(value + "=" * (-len(value) % 4)))

def hash_password(password: str) -> str:
    salt = hashlib.sha256((password + str(time.time_ns())).encode()).digest()[:16]
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 310_000)
    return base64.b64encode(salt + digest).decode()

def verify_password(password: str, encoded: str) -> bool:
    try:
        raw=base64.b64decode(encoded); salt,digest=raw[:16],raw[16:]
        return hmac.compare_digest(hashlib.pbkdf2_hmac("sha256",password.encode(),salt,310_000),digest)
    except (ValueError, TypeError, binascii.Error): return False

def bootstrap_default_admin() -> None:
    if not db.user(ADMIN_USERNAME, TENANT_ID):
        db.create_user(ADMIN_USERNAME, hash_password(ADMIN_PASSWORD), "admin", TENANT_ID)
        db.audit(TENANT_ID, ADMIN_USERNAME, "account.bootstrap", {"role":"admin"})

def issue_token(subject: str, role: str, tenant: str) -> str:
    header = _encode({"alg": "HS256", "typ": "JWT"})
    payload = _encode({"sub": subject, "role": role, "tenant": tenant, "iat": int(time.time()), "exp": int(time.time()) + JWT_TTL_MINUTES * 60})
    signature = hmac.new(JWT_SECRET.encode(), f"{header}.{payload}".encode(), hashlib.sha256).digest()
    return f"{header}.{payload}.{base64.urlsafe_b64encode(signature).rstrip(b'=').decode()}"

def authenticate(username: str, password: str) -> str:
    account = db.user(username, TENANT_ID)
    if not account or not account["enabled"] or not verify_password(password, account["password_hash"]):
        db.audit(TENANT_ID, username, "auth.login_failed")
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    db.audit(TENANT_ID, username, "auth.login")
    return issue_token(username, account["role"], account["tenant"])

def claims(credentials: HTTPAuthorizationCredentials | None = Depends(bearer)) -> dict:
    if not AUTH_REQUIRED:
        return {"username": LOCAL_USERNAME, "role": "admin", "tenant": TENANT_ID}
    if not credentials or credentials.scheme.lower() != "bearer":
        raise HTTPException(status_code=401, detail="Authentication required")
    try:
        header, payload, signature = credentials.credentials.split(".")
        expected = hmac.new(JWT_SECRET.encode(), f"{header}.{payload}".encode(), hashlib.sha256).digest()
        if not hmac.compare_digest(base64.urlsafe_b64decode(signature + "=" * (-len(signature) % 4)), expected):
            raise ValueError("signature")
        token = _decode(payload)
        if token.get("exp", 0) <= time.time() or not isinstance(token.get("sub"), str) or not isinstance(token.get("tenant"), str):
            raise ValueError("expired")
        account=db.user(token["sub"], token["tenant"])
        if not account or not account["enabled"]: raise ValueError("account")
        return {"username":account["username"],"role":account["role"],"tenant":account["tenant"]}
    except (ValueError, KeyError, json.JSONDecodeError, binascii.Error):
        raise HTTPException(status_code=401, detail="Invalid or expired access token")

def current_user(credentials: HTTPAuthorizationCredentials | None = Depends(bearer)) -> dict:
    return claims(credentials)

def current_principal(credentials: HTTPAuthorizationCredentials | None = Depends(bearer)) -> dict:
    return claims(credentials)

def current_writer(credentials: HTTPAuthorizationCredentials | None = Depends(bearer)) -> dict:
    principal = claims(credentials)
    if principal["role"] not in {"admin", "analyst", "engineer"}:
        raise HTTPException(status_code=403, detail="Analyst, engineer, or administrator role required")
    return principal

def current_admin(credentials: HTTPAuthorizationCredentials | None = Depends(bearer)) -> dict:
    token=claims(credentials)
    if token["role"] != "admin": raise HTTPException(status_code=403, detail="Administrator role required")
    return token
