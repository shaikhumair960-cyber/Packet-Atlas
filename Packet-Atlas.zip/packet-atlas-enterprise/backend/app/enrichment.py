"""Validation for a tenant's confirmed asset/CMDB CSV import."""
import csv
import io
import ipaddress

FIELDS = ("ip", "asset_name", "asset_type", "vendor", "model", "firmware", "operating_system", "zone", "criticality")
ALIASES = {"ip address":"ip", "address":"ip", "hostname":"asset_name", "name":"asset_name", "os":"operating_system", "operating system":"operating_system", "firmware version":"firmware", "purdue zone":"zone", "asset type":"asset_type"}

def template():
    return "ip,asset_name,asset_type,vendor,model,firmware,operating_system,zone,criticality\n10.10.20.15,Packaging PLC,PLC,Example Vendor,Controller X,1.2.3,Vendor runtime,Purdue L1,High\n"

def parse_csv(data: bytes) -> list[dict]:
    try: text=data.decode("utf-8-sig")
    except UnicodeDecodeError: raise ValueError("CSV must be UTF-8 encoded")
    reader=csv.DictReader(io.StringIO(text))
    if not reader.fieldnames: raise ValueError("CSV must include a header row")
    columns=[(name, ALIASES.get(name.strip().lower(),name.strip().lower().replace(" ","_"))) for name in reader.fieldnames if name]
    if "ip" not in [target for _, target in columns]: raise ValueError("CSV requires an ip column")
    records={}
    for number,row in enumerate(reader, start=2):
        values={field:"" for field in FIELDS}
        for source,target in columns:
            if target in values: values[target]=(row.get(source) or "").strip()[:256]
        if not values["ip"]: continue
        try: values["ip"]=str(ipaddress.ip_address(values["ip"]))
        except ValueError: raise ValueError(f"Invalid IP address on row {number}")
        records[values["ip"]]=values
    if not records: raise ValueError("CSV did not contain any asset records")
    if len(records)>100_000: raise ValueError("CSV exceeds the 100,000 asset limit")
    return list(records.values())
