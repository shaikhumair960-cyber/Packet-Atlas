import hashlib
import json
import logging
import os
import time
import uuid
from pathlib import Path
from fastapi import BackgroundTasks, Depends, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from . import auth, baseline, cve, db, enrichment, reports, worker
from .config import ADMIN_PASSWORD, AUTH_REQUIRED, JWT_SECRET, MAX_UPLOAD_BYTES, RECOVERY_DIR, UPLOAD_DIR

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"), format="%(asctime)s %(levelname)s %(name)s %(message)s")
LOG = logging.getLogger("packet_atlas.api")
app = FastAPI(title="Packet Atlas Enterprise API", version="1.0.0", docs_url="/api/docs", openapi_url="/api/openapi.json")
app.add_middleware(TrustedHostMiddleware, allowed_hosts=os.getenv("ALLOWED_HOSTS", "*").split(","))

class Login(BaseModel):
    username: str = Field(min_length=1, max_length=128)
    password: str = Field(min_length=1, max_length=512)

class UserCreate(BaseModel):
    username: str = Field(pattern=r"^[A-Za-z0-9_.-]{3,64}$")
    password: str = Field(min_length=8, max_length=512)
    role: str = Field(default="analyst", pattern=r"^(admin|analyst|auditor|engineer)$")

class UserUpdate(BaseModel):
    password: str | None = Field(default=None, min_length=8, max_length=512)
    role: str | None = Field(default=None, pattern=r"^(admin|analyst|auditor|engineer)$")
    enabled: bool | None = None

class CaseNote(BaseModel):
    category: str = Field(default="Analyst note", min_length=1, max_length=48)
    label: str = Field(min_length=1, max_length=160)
    note: str = Field(min_length=1, max_length=4000)

class BaselineCreate(BaseModel):
    name: str = Field(min_length=1, max_length=160)

@app.on_event("startup")
def startup():
    if AUTH_REQUIRED and (JWT_SECRET.startswith("development-only") or ADMIN_PASSWORD in {"change-me-before-production", "admin"}):
        LOG.warning("Default or development credentials are active. Change JWT_SECRET and the administrator password before production.")
    db.initialize()
    auth.bootstrap_default_admin()
    worker.recover()
    cve.start_scheduler()

@app.middleware("http")
async def secure_headers(request, call_next):
    response = await call_next(request)
    response.headers.update({"X-Content-Type-Options":"nosniff", "X-Frame-Options":"DENY", "Referrer-Policy":"no-referrer", "Cache-Control":"no-store"})
    return response

@app.post("/api/auth/login")
def login(body: Login):
    return {"access_token": auth.authenticate(body.username, body.password), "token_type":"bearer"}

@app.get("/api/auth/me")
def current_account(principal: dict = Depends(auth.current_principal)):
    return principal

@app.get("/api/admin/users")
def list_users(admin: dict = Depends(auth.current_admin)):
    return db.users(admin["tenant"])

@app.post("/api/admin/users", status_code=201)
def create_user(body: UserCreate, admin: dict = Depends(auth.current_admin)):
    if db.user(body.username, admin["tenant"]): raise HTTPException(409, "Username already exists")
    db.create_user(body.username, auth.hash_password(body.password), body.role, admin["tenant"])
    db.audit(admin["tenant"], admin["username"], "account.create", {"username":body.username,"role":body.role})
    return {"username":body.username,"role":body.role,"enabled":True}

@app.patch("/api/admin/users/{username}")
def change_user(username: str, body: UserUpdate, admin: dict = Depends(auth.current_admin)):
    existing=db.user(username, admin["tenant"])
    if not existing: raise HTTPException(404, "User not found")
    if username == admin["username"] and body.enabled is False: raise HTTPException(400, "You cannot disable your own active administrator account")
    if not db.update_user(username, admin["tenant"], auth.hash_password(body.password) if body.password else None, body.role, body.enabled): raise HTTPException(404, "User not found")
    db.audit(admin["tenant"], admin["username"], "account.update", {"username":username,"role":body.role,"enabled":body.enabled,"password_reset":bool(body.password)})
    return {"username":username,"updated":True}

@app.get("/api/health")
def health(): return {"status":"ok", "service":"packet-atlas-enterprise"}

@app.get("/api/operations/status")
def operations_status(owner: dict = Depends(auth.current_user)):
    """Expose capture queue and storage facts without crossing tenant boundaries."""
    return {**db.operations_status(owner["username"], owner["tenant"]), "worker": worker.status(),
            "limits": {"upload_bytes": MAX_UPLOAD_BYTES}}

@app.get("/api/cves/status")
def cve_feed_status(owner: dict = Depends(auth.current_user)):
    return cve.status()

@app.post("/api/admin/cves/refresh", status_code=202)
def refresh_cve_feed(background: BackgroundTasks, admin: dict = Depends(auth.current_admin)):
    background.add_task(cve.refresh_feed)
    db.audit(admin["tenant"], admin["username"], "cve.refresh_requested")
    return {"status":"queued"}

@app.get("/api/admin/audit")
def audit_log(limit: int = 100, admin: dict = Depends(auth.current_admin)):
    return db.audit_events(admin["tenant"], max(1, min(limit, 500)))

@app.get("/api/admin/assets/enrichment")
def list_asset_enrichment(admin: dict = Depends(auth.current_admin)):
    return list(db.asset_enrichment(admin["tenant"]).values())

@app.get("/api/admin/assets/template")
def asset_enrichment_template(admin: dict = Depends(auth.current_admin)):
    return Response(enrichment.template(), media_type="text/csv", headers={"Content-Disposition":"attachment; filename=packet-atlas-asset-template.csv"})

@app.post("/api/admin/assets/import")
async def import_asset_enrichment(file: UploadFile = File(...), admin: dict = Depends(auth.current_admin)):
    if not (file.filename or "").lower().endswith(".csv"):
        raise HTTPException(415, "Upload a UTF-8 CSV file")
    data = await file.read(10 * 1024 * 1024 + 1)
    await file.close()
    if len(data) > 10 * 1024 * 1024: raise HTTPException(413, "Asset CSV exceeds the 10 MB limit")
    try: records = enrichment.parse_csv(data)
    except ValueError as exc: raise HTTPException(400, str(exc))
    db.replace_asset_enrichment(admin["tenant"], records)
    db.audit(admin["tenant"], admin["username"], "asset_enrichment.import", {"records":len(records)})
    return {"imported":len(records), "tenant":admin["tenant"]}

@app.post("/api/pcaps", status_code=202)
async def upload_pcap(background: BackgroundTasks, file: UploadFile = File(...), owner: dict = Depends(auth.current_writer)):
    filename = Path(file.filename or "capture.pcap").name
    if Path(filename).suffix.lower() not in {".pcap", ".pcapng", ".cap"}:
        raise HTTPException(415, "Upload a .pcap, .pcapng, or .cap file")
    job_id = uuid.uuid4().hex; path = UPLOAD_DIR / f"{job_id}{Path(filename).suffix.lower()}"; digest=hashlib.sha256(); size=0; first=b""
    try:
        with path.open("xb") as target:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_UPLOAD_BYTES: raise HTTPException(413, f"Capture exceeds {MAX_UPLOAD_BYTES:,} byte limit")
                if len(first) < 4: first += chunk[:4-len(first)]
                digest.update(chunk); target.write(chunk)
        if size < 24 or first not in {b"\xd4\xc3\xb2\xa1",b"\xa1\xb2\xc3\xd4",b"\x4d\x3c\xb2\xa1",b"\xa1\xb2\x3c\x4d",b"\x0a\x0d\x0d\x0a"}:
            raise HTTPException(400, "File does not have a recognized PCAP or PCAPNG header")
        db.create_job({"id":job_id,"owner":owner["username"],"tenant":owner["tenant"],"filename":filename,"path":str(path),"sha256":digest.hexdigest(),"size":size,"created":time.time()})
        db.audit(owner["tenant"], owner["username"], "capture.upload", {"job_id":job_id,"filename":filename,"size":size})
        worker.submit(job_id, str(path))
        return {"id":job_id,"status":"queued","filename":filename,"size":size}
    except Exception:
        path.unlink(missing_ok=True)
        raise
    finally:
        await file.close()

@app.get("/api/pcaps")
def jobs(owner: dict = Depends(auth.current_user)): return db.list_jobs(owner["username"], owner["tenant"])

@app.get("/api/pcaps/{job_id}")
def get_analysis(job_id: str, owner: dict = Depends(auth.current_user)):
    try: return db.analysis(job_id, owner["username"], owner["tenant"])
    except KeyError: raise HTTPException(404, "Analysis not found")

@app.get("/api/pcaps/{job_id}/packets")
def packets(job_id: str, query: str = "", offset: int = 0, limit: int = 100, owner: dict = Depends(auth.current_user)):
    if not 0 <= offset <= 2_000_000 or not 1 <= limit <= 500: raise HTTPException(400, "Invalid pagination")
    try: return db.packet_page(job_id, owner["username"], owner["tenant"], query[:200], offset, limit)
    except KeyError: raise HTTPException(404, "Analysis not found")

@app.get("/api/pcaps/{job_id}/findings/{finding_id}/evidence")
def finding_evidence(job_id: str, finding_id: str, owner: dict = Depends(auth.current_user)):
    try: return db.finding_evidence(job_id, finding_id, owner["username"], owner["tenant"])
    except KeyError: raise HTTPException(404, "Finding or analysis not found")

@app.get("/api/baselines")
def list_baselines(owner: dict = Depends(auth.current_user)):
    return db.baselines_for_owner(owner["username"], owner["tenant"])

@app.post("/api/pcaps/{job_id}/baseline", status_code=201)
def mark_baseline(job_id: str, body: BaselineCreate, owner: dict = Depends(auth.current_writer)):
    try: analysis=db.analysis(job_id, owner["username"], owner["tenant"])
    except KeyError: raise HTTPException(404, "Analysis not found")
    if analysis["job"]["status"] != "complete": raise HTTPException(409, "Complete analysis before marking a baseline")
    baseline_id=uuid.uuid4().hex
    db.create_baseline({"id":baseline_id,"analysis_id":job_id,"owner":owner["username"],"tenant":owner["tenant"],"name":body.name,"snapshot":json.dumps(analysis["summary"]),"created":time.time()})
    db.audit(owner["tenant"],owner["username"],"baseline.create",{"baseline_id":baseline_id,"analysis_id":job_id,"name":body.name})
    return {"id":baseline_id,"name":body.name}

@app.get("/api/pcaps/{job_id}/compare/{baseline_id}")
def compare_baseline(job_id: str, baseline_id: str, owner: dict = Depends(auth.current_user)):
    try: return baseline.compare(db.baseline_for_owner(baseline_id,owner["username"],owner["tenant"]),db.analysis(job_id,owner["username"],owner["tenant"])["summary"])
    except KeyError: raise HTTPException(404, "Baseline or analysis not found")

@app.get("/api/pcaps/{job_id}/case-notes")
def list_case_notes(job_id: str, owner: dict = Depends(auth.current_user)):
    try: return db.case_notes(job_id, owner["username"], owner["tenant"])
    except KeyError: raise HTTPException(404, "Analysis not found")

@app.post("/api/pcaps/{job_id}/case-notes", status_code=201)
def create_case_note(job_id: str, body: CaseNote, owner: dict = Depends(auth.current_writer)):
    try:
        db.job_for_owner(job_id, owner["username"], owner["tenant"])
        note_id=db.add_case_note(job_id, owner["username"], owner["tenant"], body.category, body.label, body.note)
    except Exception as exc:
        if isinstance(exc, KeyError): raise HTTPException(404, "Analysis not found")
        raise
    db.audit(owner["tenant"], owner["username"], "case_note.create", {"analysis_id":job_id,"note_id":note_id,"category":body.category})
    return {"id":note_id,"created":True}

@app.post("/api/pcaps/{job_id}/recoveries", status_code=202)
def start_recovery(job_id: str, owner: dict = Depends(auth.current_writer)):
    try: source = db.job_for_owner(job_id, owner["username"], owner["tenant"])
    except KeyError: raise HTTPException(404, "Analysis not found")
    if source["status"] != "complete": raise HTTPException(409, "Wait for PCAP analysis to complete before starting evidence recovery")
    recovery_id = uuid.uuid4().hex
    db.create_recovery_job({"id":recovery_id,"analysis_id":job_id,"owner":owner["username"],"tenant":owner["tenant"],"path":source["path"],"created":time.time()})
    db.audit(owner["tenant"], owner["username"], "evidence_recovery.start", {"analysis_id":job_id,"recovery_id":recovery_id})
    worker.submit_recovery(recovery_id, source["path"])
    return {"id":recovery_id,"status":"queued","analysis_id":job_id}

@app.get("/api/pcaps/{job_id}/recoveries")
def analysis_recoveries(job_id: str, owner: dict = Depends(auth.current_user)):
    try:
        db.job_for_owner(job_id, owner["username"], owner["tenant"])
        return db.recoveries_for_analysis(job_id, owner["username"], owner["tenant"])
    except KeyError: raise HTTPException(404, "Analysis not found")

@app.get("/api/recoveries/{recovery_id}")
def get_recovery(recovery_id: str, owner: dict = Depends(auth.current_user)):
    try:
        return {"job":db.recovery_for_owner(recovery_id, owner["username"], owner["tenant"]), "files":db.recovered_files(recovery_id, owner["username"], owner["tenant"])}
    except KeyError: raise HTTPException(404, "Recovery job not found")

@app.get("/api/recoveries/{recovery_id}/files/{file_id}")
def download_recovered_file(recovery_id: str, file_id: int, owner: dict = Depends(auth.current_user)):
    try: record = db.recovered_file_for_owner(recovery_id, file_id, owner["username"], owner["tenant"])
    except KeyError: raise HTTPException(404, "Recovered file not found")
    root = (RECOVERY_DIR / recovery_id / "files").resolve()
    target = (root / record["stored_name"]).resolve()
    if root not in target.parents or not target.is_file(): raise HTTPException(404, "Recovered file is no longer available")
    return FileResponse(target, media_type=record["media_type"], filename=record["name"])

@app.get("/api/pcaps/{job_id}/reports/{fmt}")
def export(job_id: str, fmt: str, owner: dict = Depends(auth.current_user)):
    try: content,mime,extension=reports.build(db.analysis(job_id,owner["username"],owner["tenant"]),fmt)
    except KeyError: raise HTTPException(404, "Analysis not found")
    except ValueError as exc: raise HTTPException(400, str(exc))
    return Response(content, media_type=mime, headers={"Content-Disposition":f'attachment; filename="packet-atlas-{job_id[:8]}.{extension}"'})

@app.get("/api/pcaps/{job_id}/{section}/reports/{fmt}")
def export_section(job_id: str, section: str, fmt: str, owner: dict = Depends(auth.current_user)):
    try: content, mime, extension = reports.build_section(db.analysis(job_id, owner["username"], owner["tenant"]), section, fmt)
    except KeyError: raise HTTPException(404, "Analysis not found")
    except ValueError as exc: raise HTTPException(400, str(exc))
    return Response(content, media_type=mime, headers={"Content-Disposition":f'attachment; filename="packet-atlas-{section}-{job_id[:8]}.{extension}"'})

# Source checkout: enterprise/backend/app/main.py -> enterprise/frontend/dist.
# Container image: frontend files are deliberately copied to /app/frontend/dist.
FRONTEND = Path(os.getenv("FRONTEND_DIR", str(Path(__file__).resolve().parents[2] / "frontend" / "dist")))
if FRONTEND.exists():
    app.mount("/", StaticFiles(directory=FRONTEND, html=True), name="frontend")
