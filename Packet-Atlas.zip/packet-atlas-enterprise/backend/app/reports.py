import csv
import io
import json
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

def build(analysis: dict, fmt: str) -> tuple[bytes, str, str]:
    summary = analysis["summary"]
    job = analysis["job"]
    if fmt == "json":
        return json.dumps(analysis, indent=2, default=str).encode(), "application/json", "json"
    if fmt == "csv":
        out = io.StringIO(newline="")
        writer = csv.writer(out)
        writer.writerow(["Packet Atlas assessment", job["filename"]])
        writer.writerow([])
        writer.writerow(["Protocol", "Packets"])
        writer.writerows((item["name"], item["count"]) for item in summary.get("protocols", []))
        writer.writerow([]); writer.writerow(["Finding", "Severity", "Count", "Description", "Recommendation"])
        writer.writerows((item["title"], item["severity"], item["count"], item["description"], item["recommendation"]) for item in analysis["findings"])
        writer.writerow([]); writer.writerow(["Asset", "Asset name", "Asset type", "Vendor", "Model", "Firmware", "Operating system", "Services", "Purdue zone", "Criticality", "Confidence", "Evidence source"])
        writer.writerows((item["ip"], item.get("asset_name", ""), item.get("asset_type", "; ".join(item.get("types", []))), item.get("vendor", ""), item.get("model", ""), item.get("firmware", ""), "; ".join(item.get("os", [])), "; ".join(item.get("services", [])), "; ".join(item.get("zones", [])), item.get("criticality", ""), item.get("confidence", 0), item.get("enrichment_source", "Passive PCAP evidence")) for item in summary.get("assets", []))
        writer.writerow([]); writer.writerow(["Asset", "CVE", "CVSS", "Matched terms", "Remediation"])
        writer.writerows((item["asset"], item["id"], item.get("cvss", ""), "; ".join(item.get("match_terms", [])), item.get("remediation", "")) for item in summary.get("cves", []))
        return out.getvalue().encode("utf-8-sig"), "text/csv; charset=utf-8", "csv"
    if fmt != "pdf": raise ValueError("format must be csv, json, or pdf")
    out = io.BytesIO(); styles = getSampleStyleSheet(); story = [Paragraph("Packet Atlas Security Assessment", styles["Title"]), Spacer(1, 10), Paragraph(f"Capture: {job['filename']}", styles["Normal"]), Paragraph(f"Packets parsed: {summary.get('packet_count', 0):,}", styles["Normal"]), Spacer(1, 12)]
    protocol_rows = [["Protocol", "Packets"]] + [[item["name"], str(item["count"])] for item in summary.get("protocols", [])[:20]]
    table = Table(protocol_rows, repeatRows=1); table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1e64b7")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),0.25,colors.HexColor("#b9cbe1")),("PADDING",(0,0),(-1,-1),6)])); story += [Paragraph("Protocol distribution", styles["Heading2"]), table, Spacer(1, 12)]
    story.append(Paragraph("Traffic findings", styles["Heading2"]))
    for finding in analysis["findings"]:
        story += [Paragraph(f"{finding['severity']} — {finding['title']} ({finding['count']})", styles["Heading3"]), Paragraph(finding["description"], styles["Normal"]), Paragraph("Recommendation: " + finding["recommendation"], styles["Normal"]), Spacer(1, 8)]
    if summary.get("assets"):
        asset_rows = [["Asset", "Fingerprint", "Zone"]] + [[item["ip"], ", ".join(item.get("types", [])), ", ".join(item.get("zones", []))] for item in summary["assets"][:20]]
        assets = Table(asset_rows, repeatRows=1); assets.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1e64b7")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("GRID",(0,0),(-1,-1),0.25,colors.HexColor("#b9cbe1")),("PADDING",(0,0),(-1,-1),5)])); story += [Spacer(1, 10), Paragraph("Asset inventory", styles["Heading2"]), assets]
    if summary.get("cves"):
        story += [Spacer(1, 10), Paragraph("CVE candidates", styles["Heading2"])]
        for item in summary["cves"][:20]: story.append(Paragraph(f"{item['id']} — {item['asset']} — CVSS {item.get('cvss', 'not provided')}", styles["Normal"]))
    SimpleDocTemplate(out, pagesize=letter, leftMargin=40, rightMargin=40, topMargin=40, bottomMargin=40, title="Packet Atlas assessment").build(story)
    return out.getvalue(), "application/pdf", "pdf"

def build_section(analysis: dict, section: str, fmt: str) -> tuple[bytes, str, str]:
    """Export a focused dynamic asset or vulnerability record for one capture."""
    summary, job = analysis["summary"], analysis["job"]
    if section == "assets":
        title = "Packet Atlas Asset Inventory"
        headers = ["Asset", "Asset name", "Asset type", "Vendor", "Model", "Firmware", "Operating system", "Services", "Purdue zone", "Criticality", "Confidence", "Evidence source", "Observed banners"]
        rows = [[item["ip"], item.get("asset_name", ""), item.get("asset_type", "; ".join(item.get("types", []))), item.get("vendor", ""), item.get("model", ""), item.get("firmware", ""), "; ".join(item.get("os", [])), "; ".join(item.get("services", [])), "; ".join(item.get("zones", [])), item.get("criticality", ""), item.get("confidence", 0), item.get("enrichment_source", "Passive PCAP evidence"), "; ".join(item.get("banners", []))] for item in summary.get("assets", [])]
        payload = {"capture": job, "assets": summary.get("assets", [])}
    elif section == "vulnerabilities":
        title = "Packet Atlas Security Vulnerabilities"
        headers = ["Type", "ID or finding", "Risk / CVSS", "Affected devices", "Impact", "Recommendation"]
        rows = [[item["kind"], item["title"], f"{item['risk']}" + (f" / {item['cvss']}" if item.get("cvss") is not None else ""), "; ".join(item.get("affected_devices", [])), item["impact"], item["recommendation"]] for item in summary.get("vulnerabilities", [])]
        payload = {"capture": job, "vulnerabilities": summary.get("vulnerabilities", []), "findings": analysis.get("findings", []), "cves": summary.get("cves", []), "attack_mapping": summary.get("attack_mapping", [])}
    else:
        raise ValueError("section must be assets or vulnerabilities")
    if fmt == "json":
        return json.dumps(payload, indent=2, default=str).encode(), "application/json", "json"
    if fmt == "csv":
        out = io.StringIO(newline=""); writer = csv.writer(out); writer.writerow([title, job["filename"]]); writer.writerow([]); writer.writerow(headers); writer.writerows(rows)
        return out.getvalue().encode("utf-8-sig"), "text/csv; charset=utf-8", "csv"
    if fmt != "pdf":
        raise ValueError("format must be csv, json, or pdf")
    out = io.BytesIO(); styles = getSampleStyleSheet()
    story = [Paragraph(title, styles["Title"]), Spacer(1, 10), Paragraph(f"Capture: {job['filename']}", styles["Normal"]), Spacer(1, 10)]
    report_rows = [headers] + [[str(value)[:130] for value in row] for row in rows[:100]]
    table = Table(report_rows, repeatRows=1, colWidths=[80] * len(headers)); table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e64b7")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white), ("GRID", (0, 0), (-1, -1), .25, colors.HexColor("#b9cbe1")), ("PADDING", (0, 0), (-1, -1), 4), ("FONTSIZE", (0, 0), (-1, -1), 7)]))
    story.append(table); SimpleDocTemplate(out, pagesize=letter, leftMargin=24, rightMargin=24, topMargin=32, bottomMargin=32, title=title).build(story)
    return out.getvalue(), "application/pdf", "pdf"
