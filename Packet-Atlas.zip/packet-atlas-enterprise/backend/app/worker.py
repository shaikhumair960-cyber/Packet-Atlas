"""Restart-safe in-process analysis worker backed by queued SQLite jobs."""
from concurrent.futures import ThreadPoolExecutor
import logging
import threading
from . import analyzer, db, recovery
from .config import WORKER_THREADS

LOG = logging.getLogger("packet_atlas.worker")
_executor = ThreadPoolExecutor(max_workers=WORKER_THREADS, thread_name_prefix="packet-atlas")
_active, _lock = set(), threading.Lock()

def submit(job_id, path):
    key = f"analysis:{job_id}"
    with _lock:
        if key in _active:return False
        _active.add(key)
    def run():
        try: analyzer.parse_job(job_id,path)
        finally:
            with _lock:_active.discard(key)
    _executor.submit(run); return True

def submit_recovery(recovery_id, path):
    key = f"recovery:{recovery_id}"
    with _lock:
        if key in _active:return False
        _active.add(key)
    def run():
        try: recovery.recover_job(recovery_id, path)
        finally:
            with _lock:_active.discard(key)
    _executor.submit(run); return True

def recover():
    for job in db.recoverable_jobs():
        submit(job["id"],job["path"])
    for job in db.recoverable_recovery_jobs():
        submit_recovery(job["id"],job["path"])
    LOG.info("queued analysis recovery complete")

def status():
    """Return a small, safe view of in-process work for the operations UI."""
    with _lock:
        active = sorted(_active)
    return {
        "configured_workers": WORKER_THREADS,
        "active_workers": len(active),
        "active_analysis": sum(key.startswith("analysis:") for key in active),
        "active_recovery": sum(key.startswith("recovery:") for key in active),
    }
