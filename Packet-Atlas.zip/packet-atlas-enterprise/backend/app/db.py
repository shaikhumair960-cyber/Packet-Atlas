"""SQLite persistence with idempotent schema migrations and tenant scoping."""
import json
import sqlite3
import time
from contextlib import contextmanager
from .config import DB_PATH

@contextmanager
def connection():
    conn = sqlite3.connect(DB_PATH, timeout=30); conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    try: yield conn; conn.commit()
    finally: conn.close()

def _columns(conn, table): return {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}

def initialize():
    with connection() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, owner TEXT NOT NULL, filename TEXT NOT NULL, path TEXT NOT NULL, sha256 TEXT NOT NULL, size INTEGER NOT NULL, status TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0, packet_count INTEGER NOT NULL DEFAULT 0, created REAL NOT NULL, completed REAL, error TEXT, summary TEXT, tenant TEXT NOT NULL DEFAULT 'default');
        CREATE TABLE IF NOT EXISTS packets (job_id TEXT NOT NULL, number INTEGER NOT NULL, timestamp REAL, src TEXT, dst TEXT, sport INTEGER, dport INTEGER, protocol TEXT, length INTEGER, info TEXT, flags TEXT, PRIMARY KEY(job_id, number));
        CREATE TABLE IF NOT EXISTS findings (job_id TEXT NOT NULL, id TEXT NOT NULL, severity TEXT NOT NULL, title TEXT NOT NULL, description TEXT NOT NULL, recommendation TEXT NOT NULL, count INTEGER NOT NULL, evidence TEXT NOT NULL, PRIMARY KEY(job_id, id));
        CREATE TABLE IF NOT EXISTS users (username TEXT NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1, created REAL NOT NULL, updated REAL NOT NULL, tenant TEXT NOT NULL DEFAULT 'default', PRIMARY KEY(tenant, username));
        CREATE TABLE IF NOT EXISTS audit_events (id INTEGER PRIMARY KEY AUTOINCREMENT, created REAL NOT NULL, tenant TEXT NOT NULL, actor TEXT NOT NULL, action TEXT NOT NULL, detail TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS asset_enrichment (tenant TEXT NOT NULL, ip TEXT NOT NULL, asset_name TEXT, asset_type TEXT, vendor TEXT, model TEXT, firmware TEXT, operating_system TEXT, zone TEXT, criticality TEXT, updated REAL NOT NULL, PRIMARY KEY(tenant, ip));
        CREATE TABLE IF NOT EXISTS recovery_jobs (id TEXT PRIMARY KEY, analysis_id TEXT NOT NULL, owner TEXT NOT NULL, tenant TEXT NOT NULL, path TEXT NOT NULL, status TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0, file_count INTEGER NOT NULL DEFAULT 0, created REAL NOT NULL, completed REAL, error TEXT);
        CREATE TABLE IF NOT EXISTS recovered_files (id INTEGER PRIMARY KEY AUTOINCREMENT, recovery_id TEXT NOT NULL, name TEXT NOT NULL, stored_name TEXT NOT NULL, protocol TEXT NOT NULL, media_type TEXT NOT NULL, src TEXT, dst TEXT, size INTEGER NOT NULL, sha256 TEXT NOT NULL, created REAL NOT NULL, metadata TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS case_notes (id INTEGER PRIMARY KEY AUTOINCREMENT, analysis_id TEXT NOT NULL, owner TEXT NOT NULL, tenant TEXT NOT NULL, category TEXT NOT NULL, label TEXT NOT NULL, note TEXT NOT NULL, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS baselines (id TEXT PRIMARY KEY, analysis_id TEXT NOT NULL, owner TEXT NOT NULL, tenant TEXT NOT NULL, name TEXT NOT NULL, snapshot TEXT NOT NULL, created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS system_state (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated REAL NOT NULL);
        CREATE INDEX IF NOT EXISTS packets_job_endpoint ON packets(job_id, src, dst);
        CREATE INDEX IF NOT EXISTS packets_job_protocol ON packets(job_id, protocol);
        CREATE INDEX IF NOT EXISTS jobs_tenant_owner ON jobs(tenant, owner, created DESC);
        CREATE INDEX IF NOT EXISTS audit_tenant_created ON audit_events(tenant, created DESC);
        CREATE INDEX IF NOT EXISTS asset_enrichment_tenant ON asset_enrichment(tenant, asset_name);
        CREATE INDEX IF NOT EXISTS recovery_owner ON recovery_jobs(tenant, owner, analysis_id, created DESC);
        CREATE INDEX IF NOT EXISTS recovered_files_job ON recovered_files(recovery_id, id);
        CREATE INDEX IF NOT EXISTS case_notes_owner ON case_notes(analysis_id, tenant, owner, created DESC);
        CREATE INDEX IF NOT EXISTS baselines_owner ON baselines(tenant, owner, created DESC);
        """)
        # Compatibility migrations for installations created before tenant/audit support.
        if "tenant" not in _columns(conn, "jobs"): conn.execute("ALTER TABLE jobs ADD COLUMN tenant TEXT NOT NULL DEFAULT 'default'")
        if "tenant" not in _columns(conn, "users"): conn.execute("ALTER TABLE users ADD COLUMN tenant TEXT NOT NULL DEFAULT 'default'")
        user_keys = sorted((row[5], row[1]) for row in conn.execute("PRAGMA table_info(users)") if row[5])
        if user_keys != [(1, "tenant"), (2, "username")]:
            conn.executescript("""
            CREATE TABLE users_tenant_migration (username TEXT NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1, created REAL NOT NULL, updated REAL NOT NULL, tenant TEXT NOT NULL, PRIMARY KEY(tenant, username));
            INSERT INTO users_tenant_migration(username,password_hash,role,enabled,created,updated,tenant) SELECT username,password_hash,role,enabled,created,updated,tenant FROM users;
            DROP TABLE users;
            ALTER TABLE users_tenant_migration RENAME TO users;
            """)
        conn.execute("INSERT OR IGNORE INTO schema_migrations(version, applied) VALUES(1, ?)", (time.time(),))
        conn.execute("INSERT OR IGNORE INTO schema_migrations(version, applied) VALUES(2, ?)", (time.time(),))

def audit(tenant, actor, action, detail=None):
    with connection() as conn: conn.execute("INSERT INTO audit_events(created,tenant,actor,action,detail) VALUES(?,?,?,?,?)", (time.time(), tenant, actor, action, json.dumps(detail or {})))

def audit_events(tenant, limit=200):
    with connection() as conn: rows=conn.execute("SELECT created,actor,action,detail FROM audit_events WHERE tenant=? ORDER BY id DESC LIMIT ?",(tenant,limit)).fetchall()
    return [{**dict(row),"detail":json.loads(row["detail"])} for row in rows]

def operations_status(owner, tenant):
    """Tenant-scoped capacity and queue facts for analyst troubleshooting."""
    with connection() as conn:
        job_counts = {row["status"]: row["count"] for row in conn.execute(
            "SELECT status, COUNT(*) AS count FROM jobs WHERE owner=? AND tenant=? GROUP BY status",
            (owner, tenant),
        )}
        recovery_counts = {row["status"]: row["count"] for row in conn.execute(
            "SELECT status, COUNT(*) AS count FROM recovery_jobs WHERE owner=? AND tenant=? GROUP BY status",
            (owner, tenant),
        )}
        upload_bytes = conn.execute(
            "SELECT COALESCE(SUM(size),0) FROM jobs WHERE owner=? AND tenant=?", (owner, tenant)
        ).fetchone()[0]
        recovered_bytes = conn.execute(
            "SELECT COALESCE(SUM(f.size),0) FROM recovered_files f "
            "JOIN recovery_jobs r ON r.id=f.recovery_id WHERE r.owner=? AND r.tenant=?", (owner, tenant)
        ).fetchone()[0]
        failures = [dict(row) for row in conn.execute(
            "SELECT id,filename,created,error FROM jobs WHERE owner=? AND tenant=? AND status='failed' "
            "ORDER BY created DESC LIMIT 5", (owner, tenant)
        )]
    return {"jobs": job_counts, "recoveries": recovery_counts, "upload_bytes": upload_bytes,
            "recovered_bytes": recovered_bytes, "recent_failures": failures}

def state(key, default=None):
    with connection() as conn: row=conn.execute("SELECT value FROM system_state WHERE key=?",(key,)).fetchone()
    return row[0] if row else default

def set_state(key,value):
    with connection() as conn: conn.execute("INSERT INTO system_state(key,value,updated) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated=excluded.updated",(key,str(value),time.time()))

def replace_asset_enrichment(tenant, records):
    now=time.time()
    with connection() as conn:
        conn.execute("DELETE FROM asset_enrichment WHERE tenant=?", (tenant,))
        conn.executemany("INSERT INTO asset_enrichment(tenant,ip,asset_name,asset_type,vendor,model,firmware,operating_system,zone,criticality,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?)", [(tenant,item["ip"],item.get("asset_name",""),item.get("asset_type",""),item.get("vendor",""),item.get("model",""),item.get("firmware",""),item.get("operating_system",""),item.get("zone",""),item.get("criticality",""),now) for item in records])

def asset_enrichment(tenant):
    with connection() as conn: rows=conn.execute("SELECT ip,asset_name,asset_type,vendor,model,firmware,operating_system,zone,criticality,updated FROM asset_enrichment WHERE tenant=? ORDER BY ip",(tenant,)).fetchall()
    return {row["ip"]:dict(row) for row in rows}

def create_job(job):
    with connection() as conn: conn.execute("INSERT INTO jobs(id,owner,filename,path,sha256,size,status,progress,created,tenant) VALUES(:id,:owner,:filename,:path,:sha256,:size,'queued',0,:created,:tenant)",job)

def update_job(job_id, **values):
    if not values:return
    columns=", ".join(f"{key}=?" for key in values)
    with connection() as conn: conn.execute(f"UPDATE jobs SET {columns} WHERE id=?",(*values.values(),job_id))

def recoverable_jobs():
    with connection() as conn:
        rows=conn.execute("SELECT id,path FROM jobs WHERE status IN ('queued','running')").fetchall(); conn.execute("UPDATE jobs SET status='queued',progress=0 WHERE status='running'")
    return [dict(row) for row in rows]

def job_context(job_id):
    with connection() as conn: row=conn.execute("SELECT id,owner,tenant FROM jobs WHERE id=?",(job_id,)).fetchone()
    if not row: raise KeyError("Analysis not found")
    return dict(row)

def create_recovery_job(job):
    with connection() as conn: conn.execute("INSERT INTO recovery_jobs(id,analysis_id,owner,tenant,path,status,progress,file_count,created) VALUES(:id,:analysis_id,:owner,:tenant,:path,'queued',0,0,:created)",job)

def update_recovery_job(recovery_id, **values):
    if not values:return
    columns=", ".join(f"{key}=?" for key in values)
    with connection() as conn: conn.execute(f"UPDATE recovery_jobs SET {columns} WHERE id=?",(*values.values(),recovery_id))

def recoverable_recovery_jobs():
    with connection() as conn:
        rows=conn.execute("SELECT id,path FROM recovery_jobs WHERE status IN ('queued','running')").fetchall(); conn.execute("UPDATE recovery_jobs SET status='queued',progress=0 WHERE status='running'")
    return [dict(row) for row in rows]

def recovery_for_owner(recovery_id, owner, tenant):
    with connection() as conn: row=conn.execute("SELECT * FROM recovery_jobs WHERE id=? AND owner=? AND tenant=?",(recovery_id,owner,tenant)).fetchone()
    if not row:raise KeyError("Recovery job not found")
    return dict(row)

def recoveries_for_analysis(analysis_id, owner, tenant):
    with connection() as conn: rows=conn.execute("SELECT id,status,progress,file_count,created,completed,error FROM recovery_jobs WHERE analysis_id=? AND owner=? AND tenant=? ORDER BY created DESC",(analysis_id,owner,tenant)).fetchall()
    return [dict(row) for row in rows]

def add_recovered_file(recovery_id, record):
    with connection() as conn:
        cursor=conn.execute("INSERT INTO recovered_files(recovery_id,name,stored_name,protocol,media_type,src,dst,size,sha256,created,metadata) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(recovery_id,record["name"],record["stored_name"],record["protocol"],record["media_type"],record.get("src",""),record.get("dst",""),record["size"],record["sha256"],time.time(),json.dumps(record.get("metadata",{}))))
        conn.execute("UPDATE recovery_jobs SET file_count=file_count+1 WHERE id=?",(recovery_id,))
        file_id=cursor.lastrowid
    return file_id

def recovered_files(recovery_id, owner, tenant):
    recovery_for_owner(recovery_id,owner,tenant)
    with connection() as conn: rows=conn.execute("SELECT id,name,protocol,media_type,src,dst,size,sha256,created,metadata FROM recovered_files WHERE recovery_id=? ORDER BY id",(recovery_id,)).fetchall()
    return [{**dict(row),"metadata":json.loads(row["metadata"])} for row in rows]

def recovered_file_for_owner(recovery_id, file_id, owner, tenant):
    recovery_for_owner(recovery_id,owner,tenant)
    with connection() as conn: row=conn.execute("SELECT * FROM recovered_files WHERE recovery_id=? AND id=?",(recovery_id,file_id)).fetchone()
    if not row:raise KeyError("Recovered file not found")
    result=dict(row); result["metadata"]=json.loads(result["metadata"]); return result

def add_case_note(analysis_id, owner, tenant, category, label, note):
    with connection() as conn:
        cursor=conn.execute("INSERT INTO case_notes(analysis_id,owner,tenant,category,label,note,created) VALUES(?,?,?,?,?,?,?)",(analysis_id,owner,tenant,category,label,note,time.time()))
        return cursor.lastrowid

def case_notes(analysis_id, owner, tenant):
    job_for_owner(analysis_id, owner, tenant)
    with connection() as conn: rows=conn.execute("SELECT id,category,label,note,created FROM case_notes WHERE analysis_id=? AND owner=? AND tenant=? ORDER BY id DESC",(analysis_id,owner,tenant)).fetchall()
    return [dict(row) for row in rows]

def create_baseline(record):
    with connection() as conn: conn.execute("INSERT INTO baselines(id,analysis_id,owner,tenant,name,snapshot,created) VALUES(:id,:analysis_id,:owner,:tenant,:name,:snapshot,:created)",record)

def baselines_for_owner(owner, tenant):
    with connection() as conn: rows=conn.execute("SELECT id,analysis_id,name,created FROM baselines WHERE owner=? AND tenant=? ORDER BY created DESC",(owner,tenant)).fetchall()
    return [dict(row) for row in rows]

def baseline_for_owner(baseline_id, owner, tenant):
    with connection() as conn: row=conn.execute("SELECT * FROM baselines WHERE id=? AND owner=? AND tenant=?",(baseline_id,owner,tenant)).fetchone()
    if not row: raise KeyError("Baseline not found")
    result=dict(row); result["snapshot"]=json.loads(result["snapshot"]); return result

def finding_evidence(job_id, finding_id, owner, tenant):
    job_for_owner(job_id,owner,tenant)
    with connection() as conn:
        finding=conn.execute("SELECT * FROM findings WHERE job_id=? AND id=?",(job_id,finding_id)).fetchone()
        if not finding: raise KeyError("Finding not found")
        evidence=json.loads(finding["evidence"]); frames=[item.get("frame") for item in evidence if isinstance(item,dict) and isinstance(item.get("frame"),int)]
        rows=[] if not frames else [dict(row) for row in conn.execute("SELECT * FROM packets WHERE job_id=? AND number IN ("+",".join("?"*len(frames))+") ORDER BY number",(job_id,*frames))]
    return {"finding":{**dict(finding),"evidence":evidence},"packets":rows}

def job_for_owner(job_id, owner, tenant):
    with connection() as conn: row=conn.execute("SELECT * FROM jobs WHERE id=? AND owner=? AND tenant=?",(job_id,owner,tenant)).fetchone()
    if not row:raise KeyError("Analysis not found")
    return dict(row)

def list_jobs(owner,tenant):
    with connection() as conn:return [dict(row) for row in conn.execute("SELECT id,filename,size,status,progress,packet_count,created,completed,error FROM jobs WHERE owner=? AND tenant=? ORDER BY created DESC",(owner,tenant))]

def complete_analysis(job_id, findings, summary):
    with connection() as conn:
        conn.execute("DELETE FROM findings WHERE job_id=?",(job_id,)); conn.executemany("INSERT INTO findings VALUES(?,?,?,?,?,?,?,?)",[(job_id,item['id'],item['severity'],item['title'],item['description'],item['recommendation'],item['count'],json.dumps(item['evidence'])) for item in findings]); conn.execute("UPDATE jobs SET status='complete',progress=100,packet_count=?,completed=?,summary=? WHERE id=?",(summary['packet_count'],time.time(),json.dumps(summary),job_id))

def analysis(job_id,owner,tenant):
    job=job_for_owner(job_id,owner,tenant); summary=json.loads(job['summary']) if job['summary'] else {}
    with connection() as conn: findings=[dict(row) for row in conn.execute("SELECT * FROM findings WHERE job_id=? ORDER BY CASE severity WHEN 'High' THEN 1 WHEN 'Medium' THEN 2 ELSE 3 END",(job_id,))]
    for finding in findings: finding['evidence']=json.loads(finding['evidence'])
    return {"job":public_job(job),"summary":summary,"findings":findings}

def public_job(job): return {key:job.get(key) for key in ('id','filename','size','status','progress','packet_count','created','completed','error')}

def user(username,tenant):
    with connection() as conn: row=conn.execute("SELECT * FROM users WHERE username=? AND tenant=?",(username,tenant)).fetchone()
    return dict(row) if row else None

def users(tenant):
    with connection() as conn:return [dict(row) for row in conn.execute("SELECT username,role,enabled,created,updated,tenant FROM users WHERE tenant=? ORDER BY username",(tenant,))]

def create_user(username,password_hash,role,tenant):
    now=time.time()
    with connection() as conn:conn.execute("INSERT INTO users(username,password_hash,role,enabled,created,updated,tenant) VALUES(?,?,?,?,?,?,?)",(username,password_hash,role,1,now,now,tenant))

def update_user(username,tenant,password_hash=None,role=None,enabled=None):
    changes=[];values=[]
    if password_hash is not None:changes.append("password_hash=?");values.append(password_hash)
    if role is not None:changes.append("role=?");values.append(role)
    if enabled is not None:changes.append("enabled=?");values.append(1 if enabled else 0)
    if not changes:return user(username,tenant) is not None
    changes.append("updated=?");values.extend((time.time(),username,tenant))
    with connection() as conn:result=conn.execute("UPDATE users SET "+",".join(changes)+" WHERE username=? AND tenant=?",values)
    return result.rowcount==1

def packet_page(job_id,owner,tenant,query,offset,limit):
    job_for_owner(job_id,owner,tenant); like='%'+query.replace('%','\\%').replace('_','\\_')+'%'; where="job_id=? AND (src LIKE ? ESCAPE '\\' OR dst LIKE ? ESCAPE '\\' OR protocol LIKE ? ESCAPE '\\' OR info LIKE ? ESCAPE '\\')"; args=(job_id,like,like,like,like)
    with connection() as conn:
        total=conn.execute("SELECT COUNT(*) FROM packets WHERE "+where,args).fetchone()[0]; rows=[dict(row) for row in conn.execute("SELECT * FROM packets WHERE "+where+" ORDER BY number LIMIT ? OFFSET ?",(*args,limit,offset))]
    return {"total":total,"offset":offset,"packets":rows}
