"""Passive file recovery from supported, unencrypted PCAP protocols.

The recovery engine deliberately operates on the capture stored on disk and writes
artefacts below the application data directory.  It never stores recovered payload
bytes in SQLite.  HTTP recovery is best-effort: TCP reassembly depends on packets
being present and ordered in the capture.  TLS is intentionally not decrypted.
"""
from __future__ import annotations

import hashlib
import logging
import mimetypes
import re
import shutil
import time
from collections import defaultdict
from pathlib import Path

from scapy.all import IP, Raw, TCP, UDP, PcapReader

from . import db
from .config import MAX_RECOVERED_FILES, MAX_RECOVERED_FILE_BYTES, MAX_RECOVERY_STREAM_BYTES, RECOVERY_DIR

LOG = logging.getLogger("packet_atlas.recovery")
HTTP_PORTS = {80, 8000, 8080, 8888, 3128}


def _safe_name(value: str, fallback: str) -> str:
    name = Path((value or "").replace("\\", "/")).name
    name = re.sub(r"[^A-Za-z0-9._ -]", "_", name).strip(" .")
    return (name or fallback)[:180]


def _content_type(headers: bytes, name: str) -> str:
    match = re.search(br"(?im)^content-type:\s*([^;\r\n]+)", headers)
    if match:
        try:
            return match.group(1).decode("latin-1").strip()[:120]
        except UnicodeDecodeError:
            pass
    return mimetypes.guess_type(name)[0] or "application/octet-stream"


def _response_name(headers: bytes, path_hint: str, number: int) -> str:
    disposition = re.search(br"(?im)^content-disposition:.*?filename\*?=(?:UTF-8''|\")?([^;\r\n\"]+)", headers)
    if disposition:
        return _safe_name(disposition.group(1).decode("latin-1", "ignore"), f"http-response-{number}.bin")
    candidate = path_hint.split("?", 1)[0].rstrip("/") if path_hint else ""
    return _safe_name(candidate, f"http-response-{number}.bin")


def _decode_chunked(body: bytes, limit: int) -> bytes | None:
    output = bytearray()
    position = 0
    while True:
        end = body.find(b"\r\n", position)
        if end < 0:
            return None
        try:
            size = int(body[position:end].split(b";", 1)[0], 16)
        except ValueError:
            return None
        position = end + 2
        if size == 0:
            return bytes(output)
        if size < 0 or position + size > len(body) or len(output) + size > limit:
            return None
        output.extend(body[position:position + size])
        position += size
        if body[position:position + 2] != b"\r\n":
            return None
        position += 2


def _write_file(recovery_id: str, sequence: int, name: str, payload: bytes, protocol: str, media_type: str, src: str, dst: str, metadata: dict) -> bool:
    files_dir = RECOVERY_DIR / recovery_id / "files"
    files_dir.mkdir(parents=True, exist_ok=True)
    stored_name = f"{sequence:05d}-{_safe_name(name, 'recovered.bin')}"
    target = files_dir / stored_name
    target.write_bytes(payload)
    db.add_recovered_file(recovery_id, {
        "name": _safe_name(name, "recovered.bin"), "stored_name": stored_name, "protocol": protocol,
        "media_type": media_type, "src": src, "dst": dst, "size": len(payload),
        "sha256": hashlib.sha256(payload).hexdigest(), "metadata": metadata,
    })
    return True


def _append_stream(streams: dict, key: tuple, payload: bytes, sequence: int | None, stream_dir: Path) -> None:
    if not payload:
        return
    item = streams.setdefault(key, {"path": stream_dir / f"{len(streams):06d}.bin", "bytes": 0, "next_seq": None})
    if item["bytes"] >= MAX_RECOVERY_STREAM_BYTES:
        return
    # Captures normally retain packet order. Ignore wholly retransmitted TCP data;
    # gaps remain visible as incomplete responses rather than being guessed.
    if sequence is not None and item["next_seq"] is not None and sequence < item["next_seq"]:
        overlap = item["next_seq"] - sequence
        if overlap >= len(payload):
            return
        payload = payload[overlap:]
    payload = payload[:MAX_RECOVERY_STREAM_BYTES - item["bytes"]]
    with item["path"].open("ab") as handle:
        handle.write(payload)
    item["bytes"] += len(payload)
    if sequence is not None:
        item["next_seq"] = sequence + len(payload)


def _http_recovery(recovery_id: str, streams: dict) -> int:
    request_paths = {}
    for (src, sport, dst, dport), item in streams.items():
        if dport not in HTTP_PORTS:
            continue
        raw = item["path"].read_bytes()
        match = re.search(br"(?:GET|POST|PUT|HEAD)\s+([^\s]+)\s+HTTP/", raw)
        if match:
            request_paths[(dst, dport, src, sport)] = match.group(1).decode("latin-1", "ignore")

    count = 0
    for (src, sport, dst, dport), item in streams.items():
        if count >= MAX_RECOVERED_FILES or sport not in HTTP_PORTS:
            continue
        raw = item["path"].read_bytes()
        start = raw.find(b"HTTP/")
        if start < 0:
            continue
        header_end = raw.find(b"\r\n\r\n", start)
        if header_end < 0:
            continue
        headers, body = raw[start:header_end], raw[header_end + 4:]
        status = re.match(br"HTTP/\d(?:\.\d)?\s+(\d{3})", headers)
        if not status or not status.group(1).startswith(b"2"):
            continue
        chunked = bool(re.search(br"(?im)^transfer-encoding:\s*chunked", headers))
        if chunked:
            decoded = _decode_chunked(body, MAX_RECOVERED_FILE_BYTES)
            if decoded is None:
                continue
            body = decoded
        else:
            length = re.search(br"(?im)^content-length:\s*(\d+)", headers)
            if length:
                expected = int(length.group(1))
                if expected > MAX_RECOVERED_FILE_BYTES or len(body) < expected:
                    continue
                body = body[:expected]
            elif len(body) > MAX_RECOVERED_FILE_BYTES:
                continue
        if not body:
            continue
        name = _response_name(headers, request_paths.get((src, sport, dst, dport), ""), count + 1)
        _write_file(recovery_id, count + 1, name, body, "HTTP", _content_type(headers, name), src, dst, {
            "status": status.group(1).decode(), "request_path": request_paths.get((src, sport, dst, dport), ""),
            "chunked": chunked, "reassembly": "best-effort TCP stream",
        })
        count += 1
    return count


def _tftp_recovery(recovery_id: str, packets: list[tuple[str, int, str, int, bytes]], offset: int = 0) -> int:
    names, blocks = {}, defaultdict(dict)
    for src, sport, dst, dport, payload in packets:
        if len(payload) < 2:
            continue
        opcode = int.from_bytes(payload[:2], "big")
        if dport == 69 and opcode in {1, 2}:
            part = payload[2:].split(b"\x00", 1)[0].decode("latin-1", "ignore")
            names[(dst, src)] = _safe_name(part, "tftp-transfer.bin")
        elif opcode == 3 and len(payload) >= 4:
            block = int.from_bytes(payload[2:4], "big")
            key = (src, sport, dst, dport)
            if block not in blocks[key] and sum(len(item) for item in blocks[key].values()) < MAX_RECOVERED_FILE_BYTES:
                blocks[key][block] = payload[4:]
    count = 0
    for (src, sport, dst, dport), items in blocks.items():
        if count >= MAX_RECOVERED_FILES:
            break
        pieces, block = [], 1
        while block in items:
            pieces.append(items[block]); block += 1
        if not pieces:
            continue
        payload = b"".join(pieces)
        if len(payload) > MAX_RECOVERED_FILE_BYTES:
            continue
        name = names.get((src, dst), f"tftp-{src.replace(':','_')}-{dst.replace(':','_')}.bin")
        _write_file(recovery_id, offset + count + 1, name, payload, "TFTP", _content_type(b"", name), src, dst, {"blocks": len(pieces), "reassembly": "TFTP data blocks"})
        count += 1
    return count


def recover_job(recovery_id: str, capture_path: str) -> None:
    work_dir = RECOVERY_DIR / recovery_id
    stream_dir = work_dir / "streams"
    stream_dir.mkdir(parents=True, exist_ok=True)
    db.update_recovery_job(recovery_id, status="running", progress=2, error=None)
    streams, tftp_packets, packet_count, tftp_bytes = {}, [], 0, 0
    try:
        reader = PcapReader(capture_path)
        try:
            for packet in reader:
                packet_count += 1
                if packet_count % 5000 == 0:
                    db.update_recovery_job(recovery_id, progress=min(55, 2 + packet_count // 5000))
                if IP not in packet:
                    continue
                src, dst = packet[IP].src, packet[IP].dst
                if TCP in packet and Raw in packet:
                    tcp = packet[TCP]
                    if tcp.sport in HTTP_PORTS or tcp.dport in HTTP_PORTS:
                        _append_stream(streams, (src, int(tcp.sport), dst, int(tcp.dport)), bytes(packet[Raw].load), int(tcp.seq), stream_dir)
                elif UDP in packet and Raw in packet:
                    udp = packet[UDP]
                    payload = bytes(packet[Raw].load)
                    if (udp.sport == 69 or udp.dport == 69 or payload[:2] == b"\x00\x03") and tftp_bytes + len(payload) <= MAX_RECOVERY_STREAM_BYTES:
                        tftp_packets.append((src, int(udp.sport), dst, int(udp.dport), payload))
                        tftp_bytes += len(payload)
        finally:
            reader.close()
        db.update_recovery_job(recovery_id, progress=70)
        http_count = _http_recovery(recovery_id, streams)
        db.update_recovery_job(recovery_id, progress=85)
        tftp_count = _tftp_recovery(recovery_id, tftp_packets, http_count)
        db.update_recovery_job(recovery_id, status="complete", progress=100, completed=time.time(), error=None)
        LOG.info("recovery %s complete: %s HTTP and %s TFTP artefacts", recovery_id, http_count, tftp_count)
    except Exception as exc:
        LOG.exception("recovery %s failed", recovery_id)
        db.update_recovery_job(recovery_id, status="failed", error=str(exc)[:500], completed=time.time())
    finally:
        shutil.rmtree(stream_dir, ignore_errors=True)
