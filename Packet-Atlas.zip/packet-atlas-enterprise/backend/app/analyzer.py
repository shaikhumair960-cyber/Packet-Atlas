"""Disk-streamed, passive PCAP analysis for Packet Atlas."""
from __future__ import annotations

from collections import Counter, defaultdict
import logging
import re

from scapy.all import ARP, DNS, Ether, ICMP, IP, IPv6, Raw, TCP, UDP, PcapReader

from . import cve, db
from .config import MAX_INDEXED_PACKETS, MAX_PAYLOAD_INSPECTION_BYTES, PACKET_DB_BATCH_SIZE

LOG = logging.getLogger("packet_atlas.analyzer")
PORT_PROTOCOLS = {21:"FTP",22:"SSH",23:"Telnet",25:"SMTP",53:"DNS",80:"HTTP",110:"POP3",139:"NetBIOS",161:"SNMP",389:"LDAP",443:"TLS",445:"SMB",502:"Modbus TCP",102:"S7comm",20000:"DNP3",2404:"IEC 60870-5-104",4840:"OPC UA",44818:"EtherNet/IP",47808:"BACnet",34962:"PROFINET",34963:"PROFINET",34964:"PROFINET",3389:"RDP",5900:"VNC"}
OUI_VENDORS = {"00:00:0c":"Cisco","00:06:28":"Cisco","00:1b:21":"Intel","00:50:56":"VMware","00:15:5d":"Microsoft Hyper-V","00:1c:42":"Parallels","00:1a:11":"Google"}
MODBUS_FUNCTIONS = {1:"Read coils",2:"Read discrete inputs",3:"Read holding registers",4:"Read input registers",5:"Write single coil",6:"Write single register",15:"Write multiple coils",16:"Write multiple registers",22:"Mask write register",23:"Read/write multiple registers"}
WRITE_FUNCTIONS = {5,6,15,16,22,23}
DNP3_FUNCTIONS = {0:"Confirm",1:"Read",2:"Write",3:"Select",4:"Operate",5:"Direct operate",13:"Cold restart",14:"Warm restart"}
IEC104_CONTROL_TYPES = {45:"Single command",46:"Double command",47:"Regulating step command",48:"Set-point command (normalized)",49:"Set-point command (scaled)",50:"Set-point command (float)",58:"Single command with time tag",59:"Double command with time tag",64:"Set-point command with time tag"}
S7_FUNCTIONS = {4:"Read variable",5:"Write variable",28:"Start upload",29:"Upload",30:"End upload",40:"PLC control",41:"PLC stop"}
CIP_COMMANDS = {0x0065:"List identity",0x006f:"Send RR data",0x0070:"Send unit data"}
BACNET_BVLC = {0x00:"BVLC result",0x04:"Forwarded NPDU",0x09:"Original unicast NPDU",0x0a:"Original broadcast NPDU",0x0b:"Distribute broadcast"}
ICS_PROTOCOLS = {"Modbus TCP","DNP3","IEC 60870-5-104","OPC UA","PROFINET","S7comm","EtherNet/IP","BACnet"}
ATTACK_MAP = {"port-scan":("Discovery","T0846","Network Service Scanning"),"cleartext-telnet":("Lateral Movement","T0886","Remote Services"),"cleartext-http":("Credential Access","T0817","Drive-by Compromise review"),"basic-auth":("Credential Access","T0890","Exploitation for Credential Access review"),"ftp-cleartext-credentials":("Credential Access","T0890","Cleartext credential exposure"),"rdp-legacy-security":("Lateral Movement","T0886","Remote Services security review"),"modbus-write":("Inhibit Response Function","T0816","Device Control"),"ics-control":("Inhibit Response Function","T0816","Device Control"),"remote-access":("Lateral Movement","T0886","Remote Services"),"smb-exposure":("Lateral Movement","T1021.002","SMB/Windows Admin Shares"),"snmp-exposure":("Discovery","T0846","Network Service Scanning review"),"dns-sensitive-query":("Exfiltration","T1048","Exfiltration Over Alternative Protocol"),"tcp-null":("Discovery","T0846","Network Service Scanning"),"tcp-xmas":("Discovery","T0846","Network Service Scanning"),"purdue-crossing":("Lateral Movement","T0886","Remote Services review")}
VULNERABILITY_CONTEXT = {
    "port-scan": ("High", "Potential reconnaissance can identify exposed control-system services and enable targeted follow-on activity."),
    "cleartext-telnet": ("High", "Commands and credentials may be exposed to passive interception or unauthorized remote control."),
    "cleartext-http": ("Medium", "Management or application content may be altered or observed in transit."),
    "basic-auth": ("High", "Credential material could be reusable if the session is intercepted without adequate transport protection."),
    "ftp-cleartext-credentials": ("Critical", "FTP USER/PASS commands expose reusable credentials directly in network traffic."),
    "rdp-legacy-security": ("High", "RDP traffic did not show TLS or CredSSP negotiation and may rely on weaker legacy transport security."),
    "modbus-write": ("High", "Unapproved write activity can change controller state, setpoints, or process outputs."),
    "ics-control": ("High", "Control operations can affect RTU state, command execution, or process availability."),
    "remote-access": ("Medium", "Remote access paths can provide a route to HMI, engineering, or control systems if not governed and monitored."),
    "smb-exposure": ("Medium", "SMB can expose file shares and administrative pathways that should be segmented from OT operations."),
    "snmp-exposure": ("Medium", "SNMP can disclose network topology or device configuration when community strings and access controls are weak."),
    "dns-sensitive-query": ("High", "Long, encoded-looking, or sensitive-label DNS queries can expose secrets or indicate DNS tunneling/exfiltration."),
    "tcp-null": ("Medium", "Reconnaissance can reveal filtering behavior and expose the OT attack surface."),
    "tcp-xmas": ("Medium", "Reconnaissance can reveal filtering behavior and expose the OT attack surface."),
    "malformed-frame": ("Low", "Repeated malformed traffic can indicate capture quality issues or protocol-handling stress."),
    "purdue-crossing": ("High", "A direct enterprise-to-controller path weakens segmentation and increases operational blast radius."),
}


def _endpoint(packet):
    if IP in packet: return packet[IP].src, packet[IP].dst
    if IPv6 in packet: return packet[IPv6].src, packet[IPv6].dst
    if ARP in packet: return packet[ARP].psrc, packet[ARP].pdst
    return "", ""


def _ports(packet):
    if TCP in packet: return int(packet[TCP].sport), int(packet[TCP].dport)
    if UDP in packet: return int(packet[UDP].sport), int(packet[UDP].dport)
    return None, None


def _payload(packet): return bytes(packet[Raw])[:MAX_PAYLOAD_INSPECTION_BYTES] if Raw in packet else b""


def _protocol(packet, sport, dport, raw):
    if DNS in packet: return "DNS"
    if ARP in packet: return "ARP"
    if Ether in packet and int(packet[Ether].type) == 0x8892: return "PROFINET"
    if sport in PORT_PROTOCOLS: return PORT_PROTOCOLS[sport]
    if dport in PORT_PROTOCOLS: return PORT_PROTOCOLS[dport]
    if raw.startswith((b"HEL",b"ACK",b"ERR",b"OPN",b"MSG",b"CLO")): return "OPC UA"
    if raw.startswith(b"\x05\x64"): return "DNP3"
    if raw.startswith(b"\x68") and 2404 in {sport,dport}: return "IEC 60870-5-104"
    if TCP in packet: return "TCP"
    if UDP in packet: return "UDP"
    if ICMP in packet: return "ICMP"
    return packet.lastlayer().name[:60]


def _ics_detail(protocol, raw):
    if protocol == "Modbus TCP" and len(raw) >= 8:
        function = raw[7] & 0x7F
        label = MODBUS_FUNCTIONS.get(function, f"Function {function}")
        return f"Modbus {label}", str(function), function in WRITE_FUNCTIONS
    if protocol == "DNP3":
        function=raw[12] if len(raw)>12 else None; label=DNP3_FUNCTIONS.get(function,"application/link frame")
        return f"DNP3 {label}", str(function) if function is not None else None, function in {2,3,4,5}
    if protocol == "IEC 60870-5-104":
        label = "I-format information transfer" if len(raw) < 3 or not raw[2] & 1 else ("U-format control" if raw[2] & 3 == 3 else "S-format supervisory")
        type_id=raw[6] if len(raw)>6 and label.startswith("I-format") else None
        command=IEC104_CONTROL_TYPES.get(type_id)
        return f"IEC 104 {command or label}", str(type_id) if type_id is not None else None, type_id in IEC104_CONTROL_TYPES
    if protocol == "OPC UA": return f"OPC UA {raw[:3].decode('ascii',errors='replace') if raw else 'message'}", None, False
    if protocol == "PROFINET": return "PROFINET real-time or discovery traffic", None, False
    if protocol == "S7comm" and len(raw) >= 11 and raw[0] == 0x32:
        rosctr={1:"Job request",2:"Acknowledgement",3:"Ack data",7:"User data"}.get(raw[1],f"ROSCTR {raw[1]}")
        function=raw[10]; label=S7_FUNCTIONS.get(function,f"Function {function}")
        return f"S7comm {rosctr}: {label}",str(function),function in {5,40,41}
    if protocol == "EtherNet/IP" and len(raw) >= 2:
        command=int.from_bytes(raw[:2],"little"); label=CIP_COMMANDS.get(command,f"Encapsulation command 0x{command:04x}")
        service=raw[40] if len(raw)>40 and command in {0x006f,0x0070} else None
        service_text=f", CIP service 0x{service & 0x7f:02x}{' response' if service & 0x80 else ' request'}" if service is not None else ""
        return f"EtherNet/IP {label}{service_text}",str(service) if service is not None else str(command),bool(service is not None and not service & 0x80 and service & 0x7f in {0x4d,0x10})
    if protocol == "BACnet" and len(raw) >= 2 and raw[0] == 0x81:
        return f"BACnet {BACNET_BVLC.get(raw[1], f'BVLC function 0x{raw[1]:02x}')}",str(raw[1]),False
    return protocol, None, False


def _info(packet, protocol, operation):
    if DNS in packet and packet[DNS].qd: return f"DNS query {packet[DNS].qd.qname.decode(errors='replace').rstrip('.')}"
    if protocol in {"Modbus TCP","DNP3","IEC 60870-5-104","OPC UA","PROFINET"}: return operation
    if TCP in packet: return f"TCP flags {packet[TCP].sprintf('%TCP.flags%')}"
    if UDP in packet: return "UDP datagram"
    return protocol


def _packet_explanation(packet, protocol, operation, raw, src, dst, sport, dport):
    """Human-readable, byte-derived explanation for one indexed packet."""
    direction=f"{src}{f':{sport}' if sport else ''} → {dst}{f':{dport}' if dport else ''}"
    if protocol == "Modbus TCP" and len(raw) >= 8:
        transaction=int.from_bytes(raw[0:2],"big"); unit=raw[6]; function=raw[7] & 0x7F
        action="changes controller state or setpoints" if function in WRITE_FUNCTIONS else "requests process or device state"
        return f"{direction}. Modbus TCP transaction {transaction}, unit {unit}, function {function} ({MODBUS_FUNCTIONS.get(function, 'unrecognized function')}). This packet {action}."
    if protocol == "DNP3":
        function=raw[12] if len(raw)>12 else None; station=""
        if len(raw)>=8: station=f" DNP3 link addresses destination {int.from_bytes(raw[4:6],'little')} and source {int.from_bytes(raw[6:8],'little')}."
        action=DNP3_FUNCTIONS.get(function,"link/application traffic")
        impact=" This is a control-capable operation." if function in {2,3,4,5} else ""
        return f"{direction}. DNP3 {action}.{station}{impact}"
    if protocol == "IEC 60870-5-104":
        type_id=raw[6] if len(raw)>6 else None; command=IEC104_CONTROL_TYPES.get(type_id)
        detail=command or ("I-format information transfer" if len(raw)<3 or not raw[2] & 1 else "supervisory or U-format control")
        impact=" The ASDU represents a command/control operation." if command else ""
        return f"{direction}. IEC 60870-5-104 APDU {detail}{f' (type ID {type_id})' if type_id is not None else ''}.{impact}"
    if protocol == "OPC UA":
        message=raw[:3].decode("ascii",errors="replace") if raw else "unknown"
        size=int.from_bytes(raw[4:8],"little") if len(raw)>=8 else None
        return f"{direction}. OPC UA message {message}{f' declares {size} bytes' if size else ''}. Decode reflects transport framing; service authorization requires session context."
    if protocol == "PROFINET":
        dcp=" DCP discovery/configuration framing is present." if raw.startswith(b"\xfe\xfe") else ""
        return f"{direction}. PROFINET Ethernet frame observed.{dcp} It may represent cyclic real-time process data or discovery; the capture does not prove a configuration change without decoded application context."
    if protocol == "S7comm" and len(raw)>=11 and raw[0]==0x32:
        return f"{direction}. {operation}. ROSCTR 0x{raw[1]:02x}, parameter length {int.from_bytes(raw[6:8],'big')}, data length {int.from_bytes(raw[8:10],'big')}.{' This command can alter PLC state or variables.' if 'Write' in operation or 'control' in operation.lower() or 'stop' in operation.lower() else ''}"
    if protocol == "EtherNet/IP" and len(raw)>=2:
        command=int.from_bytes(raw[:2],"little")
        return f"{direction}. {operation}. EtherNet/IP encapsulation command 0x{command:04x}; CIP service is decoded only when present in the captured CPF payload."
    if protocol == "BACnet" and len(raw)>=2:
        return f"{direction}. {operation}. BVLC length {int.from_bytes(raw[2:4],'big') if len(raw)>=4 else 'not available'}; object/property semantics require a complete BACnet APDU."
    return _info(packet,protocol,operation)


def _banners(raw):
    """Keep only product identifiers; do not index raw payload or credentials."""
    text = raw.decode("latin-1",errors="ignore"); values=[]
    values.extend(match.group(1).strip() for match in re.finditer(r"(?im)^(?:server|x-powered-by):\s*([^\r\n]{1,120})",text))
    vendor = re.compile(r"(?i)\b(?:siemens|schneider electric|rockwell automation|honeywell|emerson|mitsubishi|omron|beckhoff|codesys)\b[^\r\n]{0,100}")
    values.extend(match.group(0).strip() for match in vendor.finditer(text))
    return list(dict.fromkeys(v for v in values if v))[:3]


def _product_hints(raw):
    """Return product/version strings only when directly disclosed by application traffic."""
    text=raw.decode("latin-1",errors="ignore"); values=[]
    for pattern in (r"(?im)^SSH-([^\r\n]{1,120})",r"(?im)^(?:220|220-)[ -]?([^\r\n]{1,120})",r"(?im)^(?:server|x-powered-by):\s*([^\r\n]{1,120})"):
        values.extend(match.group(1).strip() for match in re.finditer(pattern,text))
    return list(dict.fromkeys(value for value in values if value))[:3]


def _os_hints(raw):
    """Return passive OS/runtime fingerprints only when a banner exposes them."""
    text = raw.decode("latin-1", errors="ignore")
    patterns = [(r"(?i)windows nt\s*([0-9.]+)?", "Microsoft Windows"), (r"(?i)windows ce", "Windows CE"),
                (r"(?i)ubuntu", "Ubuntu Linux"), (r"(?i)\blinux\b", "Linux"), (r"(?i)vxworks", "VxWorks"),
                (r"(?i)\bqnx\b", "QNX"), (r"(?i)codesys", "CODESYS runtime")]
    return [label for pattern, label in patterns if re.search(pattern, text)][:2]


def _asset(assets, ip):
    """Create a useful record for every observed IP, even with no OT signature."""
    return assets.setdefault(ip, {"ip":ip, "types":{"Network endpoint"}, "services":set(), "service_ports":set(),
                                 "zones":{"Unclassified"}, "confidence":20, "banners":set(), "products":set(), "os":set(),
                                 "macs":set(), "mac_vendors":set(), "stack_profiles":set(), "packets":0})


def _stack_profile(packet):
    if IP in packet: return f"IPv4 TTL profile {int(packet[IP].ttl)}"
    if IPv6 in packet: return f"IPv6 hop-limit profile {int(packet[IPv6].hlim)}"
    return None


def _mac_vendor(mac): return OUI_VENDORS.get((mac or "")[:8].lower())


def _application_event(protocol, raw, src, dst, timestamp):
    """Return safe session context without retaining credentials or full payloads."""
    text=raw.decode("latin-1",errors="ignore")
    if protocol == "HTTP":
        match=re.search(r"(?m)^(GET|POST|PUT|DELETE|HEAD|PATCH)\s+([^\s?]{1,180})",text)
        if match:return {"protocol":"HTTP","src":src,"dst":dst,"timestamp":timestamp,"action":match.group(1),"detail":match.group(2)}
    if protocol in {"FTP","SMTP","POP3"}:
        command=text.split("\r",1)[0].split("\n",1)[0].strip()[:120]
        if command and re.match(r"^[A-Z]{3,12}(?:\s|$)",command): return {"protocol":protocol,"src":src,"dst":dst,"timestamp":timestamp,"action":"Command","detail":command}
    if protocol == "SMB": return {"protocol":"SMB","src":src,"dst":dst,"timestamp":timestamp,"action":"Session","detail":"SMB payload observed"}
    return None


def _dns_query(packet, src, dst, timestamp):
    """Extract query metadata and flag labels that merit analyst review."""
    if DNS not in packet or not packet[DNS].qd or int(packet[DNS].qr): return None
    query=packet[DNS].qd
    # `idna` has no replacement error handler. Keep malformed bytes visible
    # and non-fatal so one query cannot fail an entire multi-gigabyte capture.
    name=bytes(query.qname).decode("ascii", "replace").rstrip(".")[:253]
    qtype={1:"A",2:"NS",5:"CNAME",12:"PTR",15:"MX",16:"TXT",28:"AAAA",33:"SRV",255:"ANY"}.get(int(query.qtype), str(int(query.qtype)))
    labels=name.split("."); indicators=[]
    keywords={"password","passwd","secret","token","apikey","api-key","credential","auth","private","key"}
    if any(label.lower() in keywords or any(word in label.lower() for word in keywords) for label in labels): indicators.append("sensitive-looking label")
    longest=max((len(label) for label in labels),default=0)
    if longest >= 48 and re.fullmatch(r"[A-Za-z0-9_-]+", max(labels,key=len)): indicators.append("long encoded-looking label")
    if len(name) >= 180: indicators.append("unusually long query")
    return {"name":name,"qtype":qtype,"src":src,"dst":dst,"timestamp":timestamp,"indicators":indicators}


def _rdp_security(raw):
    """Parse the optional RDP negotiation response; absence is reported as unknown."""
    marker=raw.find(b"\x02\x00\x08\x00")
    if marker < 0 or len(raw)<marker+8: return None
    selected=int.from_bytes(raw[marker+4:marker+8],"little")
    labels={0:"Standard RDP security (TLS not observed)",1:"TLS",2:"CredSSP / Hybrid",8:"CredSSP / Hybrid EX"}
    return labels.get(selected,f"RDP negotiation protocol {selected}")


def _asset_type(types):
    priority = ("PLC", "RTU", "PROFINET", "OPC UA", "Engineering", "HMI", "Management", "Network endpoint")
    values = sorted(types)
    return next((value for needle in priority for value in values if needle.lower() in value.lower()), values[0] if values else "Network endpoint")


def _asset_role(protocol, dport):
    mapping = {("Modbus TCP",502):("PLC / Modbus server","Purdue L1",70),("DNP3",20000):("RTU / DNP3 outstation","Purdue L1",70),("IEC 60870-5-104",2404):("RTU / IEC 104 station","Purdue L1",65),("OPC UA",4840):("OPC UA server / HMI integration","Purdue L2",65)}
    if (protocol,dport) in mapping: return mapping[(protocol,dport)]
    if protocol == "PROFINET": return "PROFINET industrial device","Purdue L1",55
    if protocol in {"RDP","VNC"}: return "Engineering or HMI remote-access endpoint","Purdue L2",45
    if protocol in {"SSH","HTTP","TLS"}: return "Management or application endpoint","Purdue L3",35
    return None


def _risk(protocol, write, dport):
    return min(100, 15 + (25 if protocol in {"Modbus TCP","DNP3","IEC 60870-5-104","OPC UA","PROFINET"} else 0) + (40 if write else 0) + (20 if dport in {23,80,3389,5900} else 0))


def _ics_direction_and_key(protocol, raw, sport, dport):
    """Return request/response direction plus a byte-derived correlation key.

    The key only uses fields visible in the captured protocol frame.  Protocols
    without a safe transaction identifier deliberately use FIFO correlation and
    are labelled accordingly in the resulting evidence.
    """
    ports={port for port,name in PORT_PROTOCOLS.items() if name == protocol}
    request=dport in ports
    response=sport in ports
    key=None
    if protocol == "Modbus TCP" and len(raw) >= 8:
        key=f"mb:{int.from_bytes(raw[:2],'big')}:{raw[6]}:{raw[7] & 0x7f}"
        response=bool(raw[7] & 0x80) or response
    elif protocol == "S7comm" and len(raw) >= 6 and raw[0] == 0x32:
        key=f"s7:{raw[4:6].hex()}"
        request=raw[1] == 1
        response=raw[1] in {2,3}
    elif protocol == "EtherNet/IP" and len(raw) >= 20:
        key=f"cip:{raw[12:20].hex()}"
        if len(raw) > 40:
            request=not bool(raw[40] & 0x80)
            response=bool(raw[40] & 0x80)
    return request, response, key


def _ics_response_status(protocol, raw):
    """Describe a decoded negative response where its protocol field is visible."""
    if protocol == "Modbus TCP" and len(raw) >= 9 and raw[7] & 0x80:
        return f"Rejected - Modbus exception 0x{raw[8]:02x}"
    if protocol == "EtherNet/IP" and len(raw) >= 12:
        status=int.from_bytes(raw[8:12], "little")
        if status:
            return f"Rejected - EtherNet/IP status 0x{status:08x}"
    return "Responded"


def _transaction_record(protocol, client, server, port, timestamp):
    return {"protocol":protocol,"client":client,"server":server,"port":port,"requests":0,"responses":0,"writes":0,
            "matched":0,"unanswered":0,"rejected":0,"first_seen":timestamp,"last_seen":timestamp,"operations":[],
            "frames":[],"response_times_ms":[],"exchanges":[]}


def parse_job(job_id, path):
    """Process a capture in a FastAPI background task with bounded memory."""
    protocols=Counter(); endpoint_packets=Counter(); endpoint_bytes=Counter(); port_counts=Counter(); functions=Counter()
    assets={}; streams={}; transactions={}; pending_transactions=defaultdict(list); scans=defaultdict(set); evidence=defaultdict(list); timeline=defaultdict(lambda:[0,0]); application_events=[]; dns_queries={}; dns_indicators=[]; ftp_sessions={}; ftp_credentials=[]; rdp_security=[]
    basic_auth=Counter(); writes=Counter(); malformed=Counter(); nulls=Counter(); xmas=Counter(); rows=[]; count=indexed=0; first_seen=last_seen=None; tcp_sequences={}; retransmissions=0; tcp_gaps=0; large_gaps=0; previous_timestamp=None
    try:
        confirmed_assets=db.asset_enrichment(db.job_context(job_id)["tenant"])
        with PcapReader(path) as reader:
            for packet in reader:
                count += 1; timestamp=float(packet.time); first_seen=timestamp if first_seen is None else min(first_seen,timestamp); last_seen=timestamp if last_seen is None else max(last_seen,timestamp)
                if previous_timestamp is not None and timestamp-previous_timestamp > 60: large_gaps+=1
                previous_timestamp=timestamp
                src,dst=_endpoint(packet); sport,dport=_ports(packet); raw=_payload(packet); protocol=_protocol(packet,sport,dport,raw); operation,function,write=_ics_detail(protocol,raw); length=len(packet); flags=packet[TCP].sprintf('%TCP.flags%') if TCP in packet else ""
                if protocol in ICS_PROTOCOLS and _ics_direction_and_key(protocol,raw,sport,dport)[1]: write=False
                protocols[protocol] += 1
                if protocol == "DNS":
                    dns=_dns_query(packet,src,dst,timestamp)
                    if dns:
                        key=(dns["src"],dns["dst"],dns["name"],dns["qtype"])
                        record=dns_queries.setdefault(key,{**dns,"count":0,"first_seen":timestamp,"last_seen":timestamp})
                        record["count"]+=1; record["last_seen"]=timestamp
                        if dns["indicators"] and len(dns_indicators)<100: dns_indicators.append({"src":src,"dst":dst,"query":dns["name"],"indicators":dns["indicators"]})
                        if len(application_events)<200: application_events.append({"protocol":"DNS","src":src,"dst":dst,"timestamp":timestamp,"action":"Query" + (" · review" if dns["indicators"] else ""),"detail":dns["name"]})
                if function: functions[f"{protocol} {function}: {operation.removeprefix(protocol + ' ')}"] += 1
                for ip in (src,dst):
                    if ip: endpoint_packets[ip]+=1; endpoint_bytes[ip]+=length
                if dport is not None:
                    port_counts[dport]+=1
                    if src and dst: scans[(src,dst)].add(dport)
                bucket=int(timestamp//60)*60; timeline[bucket][0]+=1; timeline[bucket][1]+=length
                fingerprints=_banners(raw); products=_product_hints(raw); os_hints=_os_hints(raw); role=_asset_role(protocol,dport); stack=_stack_profile(packet)
                if src:
                    source_asset=_asset(assets,src); source_asset["packets"]+=1
                    if stack: source_asset["stack_profiles"].add(stack)
                    if sport in PORT_PROTOCOLS: source_asset["services"].add(PORT_PROTOCOLS[sport]); source_asset["service_ports"].add(sport)
                    if Ether in packet:
                        source_asset["macs"].add(packet[Ether].src)
                        vendor=_mac_vendor(packet[Ether].src)
                        if vendor: source_asset["mac_vendors"].add(vendor)
                if dst:
                    destination_asset=_asset(assets,dst); destination_asset["packets"]+=1
                    if dport is not None: destination_asset["services"].add(protocol); destination_asset["service_ports"].add(dport)
                    if Ether in packet:
                        destination_asset["macs"].add(packet[Ether].dst)
                        vendor=_mac_vendor(packet[Ether].dst)
                        if vendor: destination_asset["mac_vendors"].add(vendor)
                if role and dst:
                    asset=_asset(assets,dst); asset["types"].add(role[0]); asset["services"].add(protocol); asset["zones"].discard("Unclassified"); asset["zones"].add(role[1]); asset["confidence"]=max(asset["confidence"],role[2]); asset["banners"].update(fingerprints); asset["products"].update(products); asset["os"].update(os_hints)
                for banner in fingerprints:
                    if src:
                        asset=_asset(assets,src); asset["banners"].add(banner); asset["products"].update(products); asset["services"].add(protocol); asset["os"].update(os_hints); asset["confidence"]=max(asset["confidence"],45)
                if products and src:
                    asset=_asset(assets,src); asset["products"].update(products); asset["services"].add(protocol); asset["confidence"]=max(asset["confidence"],45)
                key=(src,dst,sport,dport,protocol); stream=streams.setdefault(key,{"src":src,"dst":dst,"sport":sport,"dport":dport,"protocol":protocol,"packets":0,"bytes":0,"risk":0,"writes":0,"gaps":0,"first_seen":timestamp,"last_seen":timestamp,"operations":[]}); stream["packets"]+=1; stream["bytes"]+=length; stream["last_seen"]=timestamp; stream["risk"]=max(stream["risk"],_risk(protocol,write,dport))
                if operation not in stream["operations"]: stream["operations"].append(operation)
                if protocol in ICS_PROTOCOLS:
                    service_port=dport if dport in PORT_PROTOCOLS else sport
                    client,server=(src,dst) if dport in PORT_PROTOCOLS else (dst,src)
                    flow_key=(protocol,client,server,service_port)
                    transaction=transactions.setdefault(flow_key,_transaction_record(protocol,client,server,service_port,timestamp))
                    request,response,correlation_key=_ics_direction_and_key(protocol,raw,sport,dport)
                    pending_key=(*flow_key,correlation_key or "fifo")
                    transaction["last_seen"]=timestamp
                    if operation not in transaction["operations"]: transaction["operations"].append(operation)
                    if len(transaction["frames"])<50: transaction["frames"].append(count)
                    if request:
                        transaction["requests"]+=1; transaction["writes"]+=int(write)
                        pending_transactions[pending_key].append({"frame":count,"timestamp":timestamp,"operation":operation,"write":bool(write),"correlation_key":correlation_key})
                        if len(application_events)<200: application_events.append({"protocol":protocol,"src":src,"dst":dst,"timestamp":timestamp,"action":"Control/write request" if write else "Request","detail":operation})
                    elif response:
                        transaction["responses"]+=1
                        pending=pending_transactions[pending_key]
                        if pending:
                            request_item=pending.pop(0); elapsed=max(0,round((timestamp-request_item["timestamp"])*1000,3)); status=_ics_response_status(protocol,raw)
                            exchange={"request_frame":request_item["frame"],"response_frame":count,"request_timestamp":request_item["timestamp"],"response_timestamp":timestamp,"request_operation":request_item["operation"],"response_operation":operation,"status":status,"response_time_ms":elapsed,"write":request_item["write"],"correlation_key":correlation_key or "FIFO flow correlation"}
                            transaction["matched"]+=1; transaction["rejected"]+=int(status.startswith("Rejected")); transaction["response_times_ms"].append(elapsed)
                            if len(transaction["exchanges"])<100: transaction["exchanges"].append(exchange)
                            if len(application_events)<200: application_events.append({"protocol":protocol,"src":src,"dst":dst,"timestamp":timestamp,"action":status,"detail":f"Response to frame #{request_item['frame']} in {elapsed} ms"})
                        elif len(transaction["exchanges"])<100:
                            transaction["exchanges"].append({"response_frame":count,"response_timestamp":timestamp,"response_operation":operation,"status":"Response without observed request","correlation_key":correlation_key or "FIFO flow correlation"})
                event=_application_event(protocol,raw,src,dst,timestamp)
                if event and len(application_events)<200: application_events.append(event)
                if protocol == "FTP" and dport == 21:
                    session=ftp_sessions.setdefault((src,dst,sport),{"src":src,"dst":dst,"username":"","password":"","frame":count})
                    text=raw.decode("latin-1",errors="replace")
                    username=re.search(r"(?im)^USER\s+([^\r\n]{1,200})",text)
                    password=re.search(r"(?im)^PASS\s+([^\r\n]{1,200})",text)
                    if username: session["username"]=username.group(1)
                    if password:
                        session["password"]=password.group(1)
                        if len(ftp_credentials)<100: ftp_credentials.append(dict(session))
                if protocol == "RDP":
                    security=_rdp_security(raw)
                    if security and len(rdp_security)<100: rdp_security.append({"src":src,"dst":dst,"security":security,"frame":count})
                if write:
                    stream["writes"]+=1; writes[src]+=1; evidence["ics-control"].append({"frame":count,"src":src,"dst":dst,"protocol":protocol,"operation":operation})
                    if protocol == "Modbus TCP": evidence["modbus-write"].append({"frame":count,"src":src,"dst":dst,"operation":operation})
                if protocol == "Telnet": evidence["cleartext-telnet"].append({"frame":count,"src":src,"dst":dst})
                if protocol == "HTTP": evidence["cleartext-http"].append({"frame":count,"src":src,"dst":dst})
                if b"Authorization: Basic " in raw: basic_auth[src]+=1
                if length <= 14: malformed[src]+=1; evidence["malformed-frame"].append({"frame":count,"src":src,"dst":dst})
                if TCP in packet:
                    flag_value=int(packet[TCP].flags)
                    sequence_key=(src,sport,dst,dport); sequence=int(packet[TCP].seq); previous=tcp_sequences.get(sequence_key)
                    if previous is not None and sequence < previous: retransmissions+=1
                    if previous is not None and sequence > previous:
                        tcp_gaps+=1; stream["gaps"]+=1
                    tcp_sequences[sequence_key]=max(sequence+len(raw),previous or sequence+len(raw))
                    if flag_value == 0: nulls[src]+=1; evidence["tcp-null"].append({"frame":count,"src":src,"dst":dst})
                    elif flag_value & 0x29 == 0x29: xmas[src]+=1; evidence["tcp-xmas"].append({"frame":count,"src":src,"dst":dst})
                if indexed < MAX_INDEXED_PACKETS:
                    explanation=_packet_explanation(packet,protocol,operation,raw,src,dst,sport,dport)
                    rows.append((job_id,count,timestamp,src,dst,sport,dport,protocol,length,explanation,flags)); indexed+=1
                    if len(rows)>=PACKET_DB_BATCH_SIZE: _flush(job_id,rows,count); rows=[]
        if rows: _flush(job_id,rows,count)
        asset_list=[]
        for asset in assets.values():
            confirmed=confirmed_assets.get(asset["ip"], {})
            passive_os=sorted(asset["os"]) or ["Not observed"]
            cmdb_os=confirmed.get("operating_system", "")
            evidence_bonus=min(30,8*len(asset["banners"])+8*len(asset["products"])+5*len(asset["mac_vendors"])+3*len(asset["stack_profiles"])+4*(passive_os != ["Not observed"]))
            asset_list.append({"ip":asset["ip"],"asset_name":confirmed.get("asset_name", ""),"asset_type":confirmed.get("asset_type") or _asset_type(asset["types"]),"types":sorted(asset["types"]),"services":sorted(asset["services"]),"service_ports":sorted(asset["service_ports"]),"zones":[confirmed["zone"]] if confirmed.get("zone") else sorted(asset["zones"]),"observed_zones":sorted(asset["zones"]),"confidence":min(100,max(asset["confidence"]+evidence_bonus,90 if confirmed else 0)),"banners":sorted(asset["banners"]),"products":sorted(asset["products"]),"os":[cmdb_os] if cmdb_os else passive_os,"operating_system":cmdb_os,"passive_os":passive_os,"stack_profiles":sorted(asset["stack_profiles"]),"macs":sorted(asset["macs"]),"mac_vendors":sorted(asset["mac_vendors"]),"vendor":confirmed.get("vendor", ""),"model":confirmed.get("model", ""),"firmware":confirmed.get("firmware", ""),"criticality":confirmed.get("criticality", ""),"enrichment_source":"CMDB + passive evidence" if confirmed else "Passive PCAP evidence","packets":asset["packets"]})
        asset_list.sort(key=lambda a:(-a["confidence"],-a["packets"],a["ip"]))
        zones={a["ip"]:a["zones"][0] for a in asset_list if a["zones"]}; zone_streams=Counter(); crossings=[]
        for stream in streams.values():
            source_zone=zones.get(stream["src"],"Purdue L3"); destination_zone=zones.get(stream["dst"],"Purdue L3"); zone_streams[(source_zone,destination_zone)]+=stream["packets"]
            if destination_zone == "Purdue L1" and source_zone == "Purdue L3" and stream["protocol"] not in {"DNS","NTP"}: crossings.append({**stream,"source_zone":source_zone,"destination_zone":destination_zone})
        findings=[]; vulnerability_details=[]
        def add(identifier,severity,title,description,recommendation,items,observations):
            if observations:
                finding={"id":identifier,"severity":severity,"title":title,"description":description,"recommendation":recommendation,"count":observations,"evidence":items[:100]}; findings.append(finding)
                devices=sorted({str(item.get("dst") or item.get("asset") or item.get("ip")) for item in items if item.get("dst") or item.get("asset") or item.get("ip")})
                risk,impact=VULNERABILITY_CONTEXT.get(identifier,(severity,description))
                vulnerability_details.append({"id":identifier,"kind":"Traffic indicator","title":title,"risk":risk,"impact":impact,"affected_devices":devices or ["Endpoint not identified from available packet evidence"],"recommendation":recommendation,"observations":observations,"evidence":items[:20]})
        scan_evidence=[{"src":source,"dst":destination,"distinct_ports":len(ports)} for (source,destination),ports in scans.items() if len(ports)>=20]
        add("port-scan","High","Broad destination-port probing","A source contacted at least 20 destination ports on one endpoint.","Validate the source and isolate unauthorized reconnaissance.",scan_evidence,len(scan_evidence))
        add("cleartext-telnet","High","Telnet observed","Telnet traffic was decoded from the capture.","Replace Telnet with SSH or tightly isolate the legacy path.",evidence["cleartext-telnet"],protocols["Telnet"])
        add("cleartext-http","Medium","Unencrypted HTTP observed","HTTP was decoded without transport encryption.","Move supported management and application traffic to HTTPS.",evidence["cleartext-http"],protocols["HTTP"])
        add("basic-auth","High","HTTP Basic authentication marker observed","A Basic authorization header marker was present; credential values are never stored.","Rotate exposed credentials and use TLS.",[{"src":source,"count":value} for source,value in basic_auth.items()],sum(basic_auth.values()))
        add("modbus-write","High","Modbus write commands observed","Modbus function codes indicated write activity.","Confirm initiating hosts and maintenance windows before allowing device control.",evidence["modbus-write"],len(evidence["modbus-write"]))
        non_modbus_controls=[item for item in evidence["ics-control"] if item["protocol"] != "Modbus TCP"]
        add("ics-control","High","ICS control commands observed","DNP3 or IEC 104 control/write operations were decoded. Authorization cannot be established from traffic alone.","Validate the source, device state, and approved maintenance window before accepting the command.",non_modbus_controls,len(non_modbus_controls))
        remote_streams=[stream for stream in streams.values() if stream["protocol"] in {"RDP","VNC","SSH","Telnet"}]
        add("remote-access","Medium","Remote-access service observed","A remote-management protocol was observed in the capture.","Confirm multifactor access controls, approved jump paths, session logging, and Purdue-zone restrictions.",remote_streams,len(remote_streams))
        smb_streams=[stream for stream in streams.values() if stream["protocol"] == "SMB"]
        add("smb-exposure","Medium","SMB service observed","SMB traffic was observed and can create administrative or file-transfer exposure across network zones.","Restrict SMB to approved hosts, disable legacy dialects, and enforce segmentation and signing.",smb_streams,len(smb_streams))
        snmp_streams=[stream for stream in streams.values() if stream["protocol"] == "SNMP"]
        add("snmp-exposure","Medium","SNMP management traffic observed","SNMP was observed; the capture does not establish protocol version or credential strength.","Use SNMPv3 where supported, limit managers, and restrict management-plane access.",snmp_streams,len(snmp_streams))
        add("dns-sensitive-query","High","Sensitive or encoded-looking DNS query observed","DNS query labels matched sensitive terms or an encoded/tunneling heuristic. The query name is retained as packet evidence for review.","Validate the requester and resolver, inspect the queried domain, and block unauthorized DNS egress or tunneling paths.",dns_indicators,len(dns_indicators))
        add("ftp-cleartext-credentials","Critical","Cleartext FTP credentials recovered","FTP USER/PASS commands were observed in the capture. Recovered credential evidence is shown only in the detailed assessment for authorized review.","Rotate the exposed account, remove or isolate FTP, and migrate file transfer to an encrypted, managed protocol.",ftp_credentials,len(ftp_credentials))
        legacy_rdp=[item for item in rdp_security if item["security"].startswith("Standard")]
        add("rdp-legacy-security","High","RDP without observed TLS/CredSSP negotiation","The RDP negotiation response selected legacy standard security rather than TLS or CredSSP.","Require TLS with Network Level Authentication, disable legacy RDP security, and restrict RDP to controlled jump hosts.",legacy_rdp,len(legacy_rdp))
        add("tcp-null","Medium","TCP NULL scan indicator","TCP packets with no flags were observed.","Validate the source and expected monitoring tools.",evidence["tcp-null"],sum(nulls.values()))
        add("tcp-xmas","Medium","TCP XMAS scan indicator","TCP FIN/PSH/URG flag combinations were observed.","Investigate unexpected reconnaissance behavior.",evidence["tcp-xmas"],sum(xmas.values()))
        add("malformed-frame","Low","Short or malformed frame indicator","Frames shorter than an Ethernet header were observed.","Validate capture integrity and investigate repeats.",evidence["malformed-frame"],sum(malformed.values()))
        add("purdue-crossing","High","Direct Level 3 to Level 1 traffic","A heuristic Purdue-model check observed direct enterprise-to-controller traffic.","Validate the conduit and enforce an approved intermediary or jump path.",crossings,len(crossings))
        attack=[{"finding_id":f["id"],"tactic":ATTACK_MAP[f["id"]][0],"technique_id":ATTACK_MAP[f["id"]][1],"technique":ATTACK_MAP[f["id"]][2],"observations":f["count"]} for f in findings if f["id"] in ATTACK_MAP]
        compliance=[{"framework":"IEC 62443","control":"SR 5.2 – Zone boundary protection","status":"Review" if crossings else "Observed","evidence":len(crossings)},{"framework":"IEC 62443","control":"SR 3.1 – Communication integrity","status":"Review" if protocols["Telnet"] or protocols["HTTP"] else "Observed","evidence":protocols["Telnet"]+protocols["HTTP"]},{"framework":"NIST SP 800-82","control":"Network segmentation and conduits","status":"Review" if crossings else "Observed","evidence":len(crossings)},{"framework":"NIST SP 800-82","control":"Remote access and account management","status":"Review" if protocols["Telnet"] or protocols["RDP"] else "Observed","evidence":protocols["Telnet"]+protocols["RDP"]}]
        cve_candidates=cve.match_assets(asset_list)
        for candidate in cve_candidates:
            score=candidate.get("cvss") or 0; risk="Critical" if score>=9 else "High" if score>=7 else "Medium" if score>=4 else "Low"
            vulnerability_details.append({"id":candidate["id"],"kind":"CVE candidate","title":candidate["id"],"risk":risk,"impact":candidate.get("description") or "Review the NVD record and vendor advisory for impact.","affected_devices":[candidate["asset"]],"recommendation":candidate.get("remediation"),"observations":1,"evidence":[{"match_terms":candidate.get("match_terms",[])}],"cvss":score})
        stream_list=[{**stream,"operations":sorted(stream["operations"])} for stream in sorted(streams.values(),key=lambda s:(-s["risk"],-s["packets"]))[:100]]
        # A missing response can mean loss, a partial capture, or a device issue. Keep
        # it as an explicit observation rather than treating it as proof of a failure.
        for pending_key, requests in pending_transactions.items():
            transaction=transactions[pending_key[:4]]
            for request_item in requests:
                transaction["unanswered"]+=1
                if len(transaction["exchanges"])<100: transaction["exchanges"].append({"request_frame":request_item["frame"],"request_timestamp":request_item["timestamp"],"request_operation":request_item["operation"],"write":request_item["write"],"status":"No response observed in capture","correlation_key":request_item["correlation_key"] or "FIFO flow correlation"})
        transaction_list=[]
        for transaction in transactions.values():
            timings=sorted(transaction.pop("response_times_ms"))
            transaction["operations"]=sorted(transaction["operations"])
            transaction["response_time_ms_avg"]=round(sum(timings)/len(timings),3) if timings else None
            transaction["response_time_ms_p95"]=timings[min(len(timings)-1,int(len(timings)*.95))] if timings else None
            transaction_list.append(transaction)
        transaction_list=sorted(transaction_list,key=lambda item:(-item["writes"],-item["unanswered"],-(item["requests"]+item["responses"])))[:200]
        transaction_stats={"flows":len(transaction_list),"matched":sum(item["matched"] for item in transaction_list),"unanswered":sum(item["unanswered"] for item in transaction_list),"rejected":sum(item["rejected"] for item in transaction_list),"writes":sum(item["writes"] for item in transaction_list)}
        dns_list=sorted(dns_queries.values(),key=lambda item:(-item["count"],item["name"]))[:500]
        executive_summary={"risk_posture":"Critical" if any(item["risk"]=="Critical" for item in vulnerability_details) else "High" if any(item["risk"]=="High" for item in vulnerability_details) else "Moderate" if vulnerability_details else "No implemented risk indicator observed","headline":f"{count:,} packets produced {len(asset_list)} observed assets, {len(stream_list)} indexed streams, and {len(vulnerability_details)} evidence-backed risk records.","priorities":[{"title":item["title"],"risk":item["risk"],"affected_devices":item["affected_devices"],"recommendation":item["recommendation"]} for item in vulnerability_details[:8]],"coverage":{"encrypted_packets":protocols["TLS"],"dns_queries":len(dns_queries),"ftp_credentials":len(ftp_credentials),"rdp_negotiations":len(rdp_security),"recovered_files_supported":"HTTP and TFTP"}}
        quality_score=max(0,100-min(45,malformed.total()*4)-min(25,retransmissions)-min(20,tcp_gaps)-min(20,large_gaps*2)-min(10,100 if not count else int(protocols["TLS"]*100/count)))
        topology={"nodes":[{"id":asset["ip"],"label":asset.get("asset_name") or asset["ip"],"type":asset["asset_type"],"zone":asset["zones"][0],"risk":max((stream["risk"] for stream in stream_list if asset["ip"] in {stream["src"],stream["dst"]}),default=0)} for asset in asset_list[:100]],"edges":[{"source":stream["src"],"target":stream["dst"],"protocol":stream["protocol"],"packets":stream["packets"],"risk":stream["risk"]} for stream in stream_list]}
        summary={"packet_count":count,"indexed_packet_count":indexed,"first_seen":first_seen,"last_seen":last_seen,"protocols":[{"name":name,"count":value} for name,value in protocols.most_common()],"top_ips":[{"ip":ip,"packets":value,"bytes":endpoint_bytes[ip]} for ip,value in endpoint_packets.most_common(25)],"top_ports":[{"port":port,"count":value} for port,value in port_counts.most_common(25)],"timeline":[{"timestamp":timestamp,"packets":value[0],"bytes":value[1]} for timestamp,value in sorted(timeline.items())],"ics_functions":[{"operation":name,"count":value} for name,value in functions.most_common(30)],"assets":asset_list[:100],"streams":stream_list,"transactions":transaction_list,"transaction_stats":transaction_stats,"application_events":application_events,"dns_queries":dns_list,"dns_stats":{"unique_queries":len(dns_queries),"sensitive_indicators":len(dns_indicators),"dns_packets":protocols["DNS"]},"ftp_credentials":ftp_credentials,"rdp_security":rdp_security,"executive_summary":executive_summary,"capture_quality":{"score":quality_score,"retransmissions":retransmissions,"stream_gaps":tcp_gaps,"large_time_gaps":large_gaps,"short_frames":malformed.total(),"encrypted_packets":protocols["TLS"],"explanation":"Quality reflects visible framing, timing, retransmission, and encryption constraints; it is not a security score."},"topology":topology,"zone_streams":[{"source_zone":source,"destination_zone":destination,"packets":value} for (source,destination),value in zone_streams.most_common()],"attack_mapping":attack,"cves":cve_candidates,"vulnerabilities":vulnerability_details,"compliance":compliance}
        db.complete_analysis(job_id,findings,summary)
    except Exception as exc:
        LOG.exception("analysis failed",extra={"job_id":job_id}); db.update_job(job_id,status="failed",error=str(exc)[:500])


def _flush(job_id,rows,count):
    with db.connection() as conn:
        conn.executemany("INSERT OR REPLACE INTO packets VALUES(?,?,?,?,?,?,?,?,?,?,?)",rows)
        conn.execute("UPDATE jobs SET status='running',packet_count=?,progress=? WHERE id=?",(count,50 if count else 1,job_id))
