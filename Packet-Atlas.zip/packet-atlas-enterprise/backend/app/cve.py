"""Offline-first NVD CVE feed matching.

Mount an official NVD JSON 2.0 feed at `data/nvd-cves.json` (or configure
`CVE_FEED_PATH`). A candidate is emitted only when an observed banner overlaps CPE
vendor/product tokens; a listening port alone is never treated as a vulnerable asset.
"""
from __future__ import annotations

import json
import logging
import re
import threading
import time
from pathlib import Path
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from . import db
from .config import CVE_FEED_PATH, NVD_API_KEY, NVD_API_URL, NVD_REFRESH_HOURS

LOG = logging.getLogger("packet_atlas.cve")


def status() -> dict:
    path = Path(CVE_FEED_PATH)
    return {"source": str(path), "available": path.is_file(), "updated": path.stat().st_mtime if path.is_file() else None, "last_refresh": db.state("nvd_last_refresh"), "refresh_hours": NVD_REFRESH_HOURS}

def refresh_feed() -> dict:
    """Incrementally refresh the local NVD cache without blocking PCAP analysis.

    The initial automatic window is seven days; operators can seed a full official
    NVD JSON feed before startup when historical matching is required.
    """
    now = datetime.now(timezone.utc)
    previous = db.state("nvd_last_refresh")
    try: start = datetime.fromisoformat(previous.replace("Z", "+00:00")) if previous else now - timedelta(days=7)
    except ValueError: start = now - timedelta(days=7)
    if start < now - timedelta(days=120): start = now - timedelta(days=120)
    query = urlencode({"lastModStartDate": start.isoformat(timespec="milliseconds"), "lastModEndDate": now.isoformat(timespec="milliseconds"), "resultsPerPage": 2000})
    headers = {"User-Agent": "Packet-Atlas-Enterprise/1.2"}
    if NVD_API_KEY: headers["apiKey"] = NVD_API_KEY
    existing = {}
    path = Path(CVE_FEED_PATH)
    if path.is_file():
        try: existing = {row.get("cve", row).get("id"): row for row in _records(json.loads(path.read_text(encoding="utf-8"))) if row.get("cve", row).get("id")}
        except (OSError, json.JSONDecodeError): existing = {}
    start_index = 0; fetched = 0
    while start_index < 10_000:
        request = Request(f"{NVD_API_URL}?{query}&startIndex={start_index}", headers=headers)
        with urlopen(request, timeout=30) as response: payload = json.loads(response.read().decode("utf-8"))
        rows = payload.get("vulnerabilities", []); fetched += len(rows)
        for row in rows: existing[row.get("cve", row).get("id")] = row
        total = int(payload.get("totalResults", 0))
        start_index += len(rows)
        if not rows or start_index >= total: break
        time.sleep(6 if not NVD_API_KEY else .7)
    path.parent.mkdir(parents=True, exist_ok=True); path.write_text(json.dumps({"vulnerabilities": list(existing.values())}), encoding="utf-8")
    db.set_state("nvd_last_refresh", now.isoformat()); LOG.info("NVD feed refreshed: %s records", fetched)
    return {"fetched": fetched, "stored": len(existing), "refreshed": now.isoformat()}

def start_scheduler():
    def run():
        while True:
            try:
                current = Path(CVE_FEED_PATH)
                age = time.time() - current.stat().st_mtime if current.is_file() else float("inf")
                if age >= NVD_REFRESH_HOURS * 3600: refresh_feed()
            except Exception: LOG.warning("NVD refresh did not complete", exc_info=True)
            time.sleep(min(NVD_REFRESH_HOURS * 3600, 3600))
    threading.Thread(target=run, name="nvd-refresh", daemon=True).start()


def _records(payload):
    if isinstance(payload, list):
        return payload
    return payload.get("vulnerabilities", []) if isinstance(payload, dict) else []


def _record(row):
    item = row.get("cve", row)
    identifier = item.get("id")
    if not identifier:
        return None
    metrics = item.get("metrics", {})
    metric = next(iter(metrics.get("cvssMetricV31", []) or metrics.get("cvssMetricV30", []) or metrics.get("cvssMetricV2", [])), {})
    cvss = metric.get("cvssData", {}).get("baseScore")
    description = next((value.get("value", "") for value in item.get("descriptions", []) if value.get("lang") == "en"), "")
    criteria = []
    for configuration in item.get("configurations", []):
        for node in configuration.get("nodes", []):
            criteria.extend(match.get("criteria", "") for match in node.get("cpeMatch", []))
    return {"id": identifier, "cvss": cvss, "description": description, "criteria": criteria,
            "remediation": "Validate the exact vendor, product, and version against the vendor advisory; patch or apply compensating controls."}


def _tokens(value):
    return {token for token in re.findall(r"[a-z0-9][a-z0-9._-]{2,}", value.lower()) if token not in {"the", "and", "for", "with", "version", "vendor", "product"}}


def match_assets(assets: list[dict]) -> list[dict]:
    path = Path(CVE_FEED_PATH)
    if not path.is_file():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    candidates = []
    for asset in assets:
        # A banner or a confirmed CMDB product record provides the evidence needed for a CPE match.
        confirmed = [asset.get("vendor", ""), asset.get("model", ""), asset.get("firmware", ""), asset.get("operating_system", "")]
        if not asset.get("banners") and not any(confirmed):
            continue
        observed = _tokens(" ".join([*asset.get("types", []), *asset.get("services", []), *asset.get("banners", []), *confirmed]))
        for row in _records(payload):
            record = _record(row)
            if not record:
                continue
            overlap = observed & _tokens(" ".join(record["criteria"]))
            if len(overlap) >= 2:
                candidates.append({"asset": asset["ip"], "id": record["id"], "cvss": record["cvss"], "description": record["description"], "remediation": record["remediation"], "match_terms": sorted(overlap)})
    unique = {(item["asset"], item["id"]): item for item in candidates}
    return sorted(unique.values(), key=lambda item: (-(item["cvss"] or 0), item["id"]))[:100]
