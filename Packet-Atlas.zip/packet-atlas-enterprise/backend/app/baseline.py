"""Capture-baseline comparison using only persisted analysis evidence."""
from __future__ import annotations

def _assets(summary): return {item["ip"]:item for item in summary.get("assets",[])}
def _ports(summary): return {item["port"] for item in summary.get("top_ports",[])}
def _writes(summary): return {(item.get("client"),item.get("server"),tuple(item.get("operations",[]))) for item in summary.get("transactions",[]) if item.get("writes")}
def _remote(summary): return {(item.get("src"),item.get("dst"),item.get("protocol")) for item in summary.get("streams",[]) if item.get("protocol") in {"RDP","VNC","SSH","Telnet"}}
def _crossings(summary): return {(item.get("source_zone"),item.get("destination_zone")) for item in summary.get("zone_streams",[])}

def compare(baseline, current):
    before,after=baseline["snapshot"],current
    old_assets,new_assets=_assets(before),_assets(after)
    deviations=[]
    for ip in sorted(set(new_assets)-set(old_assets)):
        deviations.append({"type":"New asset","severity":"High" if new_assets[ip].get("zones",[""])[0]=="Purdue L1" else "Medium","asset":ip,"detail":new_assets[ip].get("asset_type","Network endpoint"),"evidence":{"asset":new_assets[ip]}})
    for ip in sorted(set(new_assets)&set(old_assets)):
        changed={field:[old_assets[ip].get(field),new_assets[ip].get(field)] for field in ("banners","products","firmware","operating_system") if old_assets[ip].get(field)!=new_assets[ip].get(field)}
        if changed: deviations.append({"type":"Fingerprint changed","severity":"Medium","asset":ip,"detail":"Passive product or firmware evidence changed","evidence":changed})
    for port in sorted(_ports(after)-_ports(before)): deviations.append({"type":"New service port","severity":"Medium","asset":"","detail":str(port),"evidence":{"port":port}})
    for item in sorted(_writes(after)-_writes(before)): deviations.append({"type":"New control/write sequence","severity":"High","asset":item[1] or "","detail":" → ".join(filter(None,item[2])),"evidence":{"client":item[0],"server":item[1]}})
    for item in sorted(_remote(after)-_remote(before)): deviations.append({"type":"New remote access path","severity":"High","asset":item[1],"detail":f"{item[2]} from {item[0]}","evidence":{"stream":item}})
    for item in sorted(_crossings(after)-_crossings(before)): deviations.append({"type":"New zone conduit","severity":"High" if item[1]=="Purdue L1" else "Medium","asset":"","detail":f"{item[0]} → {item[1]}","evidence":{"zones":item}})
    if after.get("dns_stats",{}).get("sensitive_indicators",0)>before.get("dns_stats",{}).get("sensitive_indicators",0): deviations.append({"type":"New DNS risk indicator","severity":"High","asset":"","detail":"Sensitive or encoded-looking DNS query indicators increased","evidence":{"baseline":before.get("dns_stats",{}),"current":after.get("dns_stats",{})}})
    order={"Critical":0,"High":1,"Medium":2,"Low":3}
    return {"baseline":{"id":baseline["id"],"name":baseline["name"],"analysis_id":baseline["analysis_id"]},"deviations":sorted(deviations,key=lambda item:order.get(item["severity"],4)),"summary":{"total":len(deviations),"high_or_critical":sum(item["severity"] in {"High","Critical"} for item in deviations)}}
