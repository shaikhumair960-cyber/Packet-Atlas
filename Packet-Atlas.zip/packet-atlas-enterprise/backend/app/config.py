from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = Path(os.getenv("DATA_DIR", ROOT / "data"))
UPLOAD_DIR = DATA_DIR / "uploads"
RECOVERY_DIR = DATA_DIR / "recovered"
DB_PATH = DATA_DIR / "packet_atlas.sqlite3"
MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_BYTES", str(2 * 1024 * 1024 * 1024)))
MAX_INDEXED_PACKETS = int(os.getenv("MAX_INDEXED_PACKETS", "2000000"))
PACKET_DB_BATCH_SIZE = max(500, int(os.getenv("PACKET_DB_BATCH_SIZE", "5000")))
MAX_PAYLOAD_INSPECTION_BYTES = max(256, int(os.getenv("MAX_PAYLOAD_INSPECTION_BYTES", "4096")))
JWT_SECRET = os.getenv("JWT_SECRET", "development-only-change-this-secret-before-production")
JWT_TTL_MINUTES = int(os.getenv("JWT_TTL_MINUTES", "60"))
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin")
CVE_FEED_PATH = os.getenv("CVE_FEED_PATH", str(DATA_DIR / "nvd-cves.json"))
TENANT_ID = os.getenv("TENANT_ID", "default")
AUTH_REQUIRED = os.getenv("AUTH_REQUIRED", "false").strip().lower() in {"1", "true", "yes", "on"}
LOCAL_USERNAME = os.getenv("LOCAL_USERNAME", "local")
WORKER_THREADS = max(1, int(os.getenv("WORKER_THREADS", "2")))
NVD_API_URL = os.getenv("NVD_API_URL", "https://services.nvd.nist.gov/rest/json/cves/2.0")
NVD_API_KEY = os.getenv("NVD_API_KEY", "")
NVD_REFRESH_HOURS = max(1, int(os.getenv("NVD_REFRESH_HOURS", "24")))
MAX_RECOVERED_FILE_BYTES = max(1, int(os.getenv("MAX_RECOVERED_FILE_BYTES", str(100 * 1024 * 1024))))
MAX_RECOVERY_STREAM_BYTES = max(MAX_RECOVERED_FILE_BYTES, int(os.getenv("MAX_RECOVERY_STREAM_BYTES", str(256 * 1024 * 1024))))
MAX_RECOVERED_FILES = max(1, int(os.getenv("MAX_RECOVERED_FILES", "1000")))

for directory in (DATA_DIR, UPLOAD_DIR, RECOVERY_DIR):
    directory.mkdir(parents=True, exist_ok=True)
